
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, Bookmark, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface NewsItem {
  id: number;
  title: string;
  source: string;
  category: string;
  time: string;
  url: string;
  impact: "high" | "medium" | "low";
}

// Sample news data
const newsData: NewsItem[] = [
  {
    id: 1,
    title: "Federal Reserve raises interest rates by 0.25%",
    source: "Financial Times",
    category: "Economy",
    time: "2h ago",
    url: "#",
    impact: "high"
  },
  {
    id: 2,
    title: "Apple announces new iPhone launch date",
    source: "TechCrunch",
    category: "Technology",
    time: "4h ago",
    url: "#",
    impact: "medium"
  },
  {
    id: 3,
    title: "Oil prices drop amid supply chain concerns",
    source: "Bloomberg",
    category: "Commodities",
    time: "6h ago",
    url: "#",
    impact: "medium"
  },
  {
    id: 4,
    title: "Tesla exceeds quarterly delivery expectations",
    source: "Reuters",
    category: "Automotive",
    time: "10h ago",
    url: "#",
    impact: "high"
  },
  {
    id: 5,
    title: "New healthcare bill passes Senate vote",
    source: "CNBC",
    category: "Healthcare",
    time: "12h ago",
    url: "#",
    impact: "medium"
  },
  {
    id: 6,
    title: "Retail sales show unexpected growth in Q2",
    source: "Wall Street Journal",
    category: "Retail",
    time: "1d ago",
    url: "#",
    impact: "low"
  }
];

const getImpactColor = (impact: "high" | "medium" | "low") => {
  switch (impact) {
    case "high":
      return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400";
    case "medium":
      return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400";
    case "low":
      return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400";
    default:
      return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400";
  }
};

export default function NewsFeed() {
  return (
    <Card className="h-full animate-fade-in">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-2xl font-bold">Market News</CardTitle>
        <Button variant="ghost" size="sm" className="gap-1">
          <span className="text-sm">View All</span>
          <ArrowUpRight size={16} />
        </Button>
      </CardHeader>
      <CardContent className="px-2">
        <div className="space-y-4 h-[340px] overflow-y-auto pr-2 scrollbar-thin">
          {newsData.map((news) => (
            <div
              key={news.id}
              className="p-3 bg-background rounded-lg border border-border transition-all hover:shadow-md"
            >
              <div className="flex justify-between items-start gap-2">
                <div className="flex-1">
                  <h3 className="font-medium text-sm line-clamp-2">{news.title}</h3>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline" className="text-xs font-normal">
                      {news.category}
                    </Badge>
                    <Badge
                      variant="outline"
                      className={`text-xs font-normal ${getImpactColor(news.impact)}`}
                    >
                      {news.impact.charAt(0).toUpperCase() + news.impact.slice(1)} Impact
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-muted-foreground">
                      {news.source} · {news.time}
                    </span>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Bookmark size={14} />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Share2 size={14} />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
