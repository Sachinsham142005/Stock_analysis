
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Line, 
  LineChart 
} from "recharts";

// Sample data - would come from an API
const generateData = (days: number, startValue = 150, volatility = 5, trend = 0.1) => {
  const data = [];
  let currentValue = startValue;

  for (let i = 0; i < days; i++) {
    const random = (Math.random() - 0.5) * volatility;
    currentValue = Math.max(currentValue + random + trend, 10);
    data.push({
      date: new Date(Date.now() - (days - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
      value: parseFloat(currentValue.toFixed(2))
    });
  }
  return data;
};

const timeRanges = [
  { label: "1D", days: 1 },
  { label: "1W", days: 7 },
  { label: "1M", days: 30 },
  { label: "3M", days: 90 },
  { label: "1Y", days: 365 },
  { label: "ALL", days: 1095 }
];

export default function MainChart() {
  const [activeRange, setActiveRange] = useState("1M");
  const [chartData, setChartData] = useState(generateData(30));
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const selectedRange = timeRanges.find(range => range.label === activeRange);
    if (selectedRange) {
      setIsAnimating(true);
      const days = selectedRange.days;
      // Simulating data fetch with setTimeout
      setTimeout(() => {
        setChartData(generateData(days));
        setIsAnimating(false);
      }, 300);
    }
  }, [activeRange]);

  // Calculate if the trend is positive
  const isPositive = chartData[0]?.value <= chartData[chartData.length - 1]?.value;
  const firstValue = chartData[0]?.value || 0;
  const lastValue = chartData[chartData.length - 1]?.value || 0;
  const change = lastValue - firstValue;
  const changePercent = (change / firstValue) * 100;

  return (
    <Card className="w-full h-[400px] animate-fade-in">
      <CardHeader className="pb-0">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-2xl font-bold">S&P 500</CardTitle>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-xl font-bold">${lastValue.toFixed(2)}</span>
              <span className={`text-sm font-medium ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                {isPositive ? '+' : ''}{change.toFixed(2)} ({changePercent.toFixed(2)}%)
              </span>
            </div>
          </div>
          <Tabs 
            value={activeRange} 
            onValueChange={setActiveRange}
            className="mt-2"
          >
            <TabsList className="bg-muted/50">
              {timeRanges.map(range => (
                <TabsTrigger
                  key={range.label}
                  value={range.label}
                  className="px-3 py-1 data-[state=active]:bg-primary data-[state=active]:text-white transition-all"
                >
                  {range.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent className="pt-6 h-[300px]">
        {isAnimating ? (
          <div className="w-full h-full flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={chartData}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop
                    offset="5%"
                    stopColor={isPositive ? "rgb(16, 185, 129)" : "rgb(239, 68, 68)"}
                    stopOpacity={0.4}
                  />
                  <stop
                    offset="95%"
                    stopColor={isPositive ? "rgb(16, 185, 129)" : "rgb(239, 68, 68)"}
                    stopOpacity={0}
                  />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
              <XAxis
                dataKey="date"
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12 }}
                tickMargin={10}
                tickFormatter={(value) => {
                  // Format based on time range
                  if (activeRange === "1D") return value.split("/")[1];
                  if (activeRange === "1W") return value.split("/")[1] + "/" + value.split("/")[0];
                  return value;
                }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12 }}
                tickMargin={10}
                domain={["dataMin - 5", "dataMax + 5"]}
                tickFormatter={(value) => `$${value}`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(0, 0, 0, 0.7)",
                  border: "none",
                  borderRadius: "4px",
                  color: "#fff",
                  fontSize: "12px",
                }}
                labelFormatter={(label) => `Date: ${label}`}
                formatter={(value: number) => [`$${value.toFixed(2)}`, "Value"]}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke={isPositive ? "rgb(16, 185, 129)" : "rgb(239, 68, 68)"}
                fillOpacity={1}
                fill="url(#colorValue)"
                strokeWidth={2}
                activeDot={{ r: 6 }}
                isAnimationActive={true}
                animationDuration={1000}
                animationEasing="ease-in-out"
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}
