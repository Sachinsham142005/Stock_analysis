
import { Activity, ArrowUpRight, TrendingUp, Users, DollarSign } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function StatsGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatsCard
        title="Portfolio Value"
        value="$42,530.89"
        change="+5.25%"
        description="from last month"
        icon={<DollarSign className="h-5 w-5" />}
        trend="up"
        delay={0.1}
      />
      <StatsCard
        title="Daily Trading Volume"
        value="$128.3M"
        change="+2.5%"
        description="from yesterday"
        icon={<Activity className="h-5 w-5" />}
        trend="up"
        delay={0.2}
      />
      <StatsCard
        title="Active Stocks"
        value="36"
        change="+8"
        description="new this week"
        icon={<TrendingUp className="h-5 w-5" />}
        trend="up"
        delay={0.3}
      />
      <StatsCard
        title="Market Participants"
        value="12.5K"
        change="+3.2%"
        description="from last week"
        icon={<Users className="h-5 w-5" />}
        trend="up"
        delay={0.4}
      />
    </div>
  );
}

interface StatsCardProps {
  title: string;
  value: string;
  change: string;
  description: string;
  icon: React.ReactNode;
  trend: "up" | "down";
  delay: number;
}

function StatsCard({ title, value, change, description, icon, trend, delay }: StatsCardProps) {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md animate-in fade-in slide-in-from-bottom duration-300" style={{ animationDelay: `${delay}s` }}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
          <span className={trend === "up" ? "text-green-500" : "text-red-500"}>
            {change}
          </span>
          <ArrowUpRight className={`h-3 w-3 ${trend === "up" ? "text-green-500" : "text-red-500"}`} />
          <span>{description}</span>
        </p>
      </CardContent>
    </Card>
  );
}
