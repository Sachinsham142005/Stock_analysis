
import { useState, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { Upload, ArrowRight, LineChart, BarChart3, PieChart } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, LineChart as RechartsLineChart, Line } from "recharts";
import { Badge } from "@/components/ui/badge";

// Sample prediction data
const sampleAnalysis = {
  summary: {
    totalInvestment: 25000,
    predictedReturn: 2750,
    returnPercentage: 11,
    riskLevel: "Moderate",
    recommendation: "Buy",
    confidenceScore: 76
  },
  sectorDistribution: [
    { name: "Technology", value: 45 },
    { name: "Healthcare", value: 20 },
    { name: "Financial", value: 15 },
    { name: "Consumer", value: 10 },
    { name: "Energy", value: 10 }
  ],
  performanceData: [
    { month: "Jan", actual: 5, predicted: 5.5 },
    { month: "Feb", actual: 7, predicted: 6.8 },
    { month: "Mar", actual: 8, predicted: 8.2 },
    { month: "Apr", actual: 6, predicted: 7.5 },
    { month: "May", actual: 9, predicted: 8.7 },
    { month: "Jun", actual: 11, predicted: 10.2 }
  ],
  riskData: [
    { name: "Volatility", value: 65 },
    { name: "Market Correlation", value: 72 },
    { name: "Liquidity Risk", value: 45 },
    { name: "Concentration Risk", value: 58 }
  ]
};

// Colors for pie chart
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function MarketAnalyzer() {
  const [file, setFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<typeof sampleAnalysis | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // Check if file is CSV
      if (selectedFile.type !== "text/csv" && !selectedFile.name.endsWith('.csv')) {
        toast({
          title: "Invalid file format",
          description: "Please upload a CSV file.",
          variant: "destructive"
        });
        return;
      }
      
      setFile(selectedFile);
      toast({
        title: "File uploaded",
        description: `${selectedFile.name} has been uploaded successfully.`,
      });
    }
  };

  const handleAnalyze = () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please upload a CSV file to analyze.",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);
    
    // Simulate analysis (in a real app, this would send data to a backend)
    setTimeout(() => {
      setAnalysis(sampleAnalysis);
      setIsAnalyzing(false);
      toast({
        title: "Analysis Complete",
        description: "Market data has been analyzed successfully!",
      });
    }, 1500);
  };

  const resetAnalysis = () => {
    setFile(null);
    setAnalysis(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="text-2xl">Market Analyzer</CardTitle>
        <CardDescription>
          Upload your CSV file with market data to get AI-powered predictions and insights
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!analysis ? (
          <div className="space-y-4">
            <div className="border-2 border-dashed rounded-lg p-6 text-center hover:bg-muted/50 transition-colors cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              <Upload className="h-10 w-10 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium mb-1">Upload CSV File</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Drag and drop your market data file or click to browse
              </p>
              <Input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                className="hidden"
                onChange={handleFileChange}
              />
              <Button variant="outline" onClick={(e) => {
                e.stopPropagation();
                fileInputRef.current?.click();
              }}>
                Select File
              </Button>
            </div>
            
            {file && (
              <div className="bg-muted/50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{file.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(file.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                  <Button 
                    onClick={handleAnalyze} 
                    disabled={isAnalyzing}
                    className="gap-2"
                  >
                    {isAnalyzing ? (
                      <>Analyzing<span className="animate-pulse">...</span></>
                    ) : (
                      <>Analyze <ArrowRight className="h-4 w-4" /></>
                    )}
                  </Button>
                </div>
              </div>
            )}
            
            <div className="bg-muted/30 p-4 rounded-md mt-6">
              <h3 className="font-medium mb-2 flex items-center">
                <LineChart className="h-4 w-4 mr-2" />
                Sample CSV Format
              </h3>
              <p className="text-sm text-muted-foreground mb-2">
                Your CSV should include the following columns:
              </p>
              <div className="text-xs bg-background p-2 rounded-md font-mono overflow-x-auto">
                date,symbol,open,high,low,close,volume
                <br />
                2024-01-15,AAPL,185.42,186.74,184.53,185.92,48572300
                <br />
                2024-01-16,AAPL,186.12,187.67,184.89,186.32,52148700
                <br />
                ...
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium">Analysis Results</h3>
              <Button variant="outline" onClick={resetAnalysis}>
                New Analysis
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Predicted Return</p>
                    <h3 className="text-3xl font-bold text-green-500">+{analysis.summary.returnPercentage}%</h3>
                    <p className="text-sm">+${analysis.summary.predictedReturn}</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Risk Level</p>
                    <h3 className="text-3xl font-bold text-amber-500">{analysis.summary.riskLevel}</h3>
                    <p className="text-sm">Confidence: {analysis.summary.confidenceScore}%</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Recommendation</p>
                    <h3 className="text-3xl font-bold text-primary">{analysis.summary.recommendation}</h3>
                    <Badge variant={analysis.summary.recommendation === "Buy" ? "default" : "outline"}>
                      {analysis.summary.recommendation === "Buy" ? "Positive Outlook" : "Cautious Outlook"}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Tabs defaultValue="distribution">
              <TabsList className="w-full justify-start mb-4">
                <TabsTrigger value="distribution" className="gap-2">
                  <PieChart className="h-4 w-4" />
                  Sector Distribution
                </TabsTrigger>
                <TabsTrigger value="performance" className="gap-2">
                  <LineChart className="h-4 w-4" />
                  Performance
                </TabsTrigger>
                <TabsTrigger value="risk" className="gap-2">
                  <BarChart3 className="h-4 w-4" />
                  Risk Analysis
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="distribution">
                <Card>
                  <CardContent className="pt-6">
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={analysis.sectorDistribution}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {analysis.sectorDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => `${value}%`} />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex justify-center gap-4 mt-4 flex-wrap">
                      {analysis.sectorDistribution.map((entry, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: COLORS[index % COLORS.length] }}
                          />
                          <span className="text-sm">{entry.name}: {entry.value}%</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="performance">
                <Card>
                  <CardContent className="pt-6">
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsLineChart
                          data={analysis.performanceData}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line
                            type="monotone"
                            dataKey="actual"
                            stroke="#8884d8"
                            activeDot={{ r: 8 }}
                          />
                          <Line type="monotone" dataKey="predicted" stroke="#82ca9d" />
                        </RechartsLineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="risk">
                <Card>
                  <CardContent className="pt-6">
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={analysis.riskData}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="value" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
