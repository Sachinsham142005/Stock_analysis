
import { useState, useRef, useEffect } from "react";
import { X, Send, Maximize2, Minimize2, ChevronDown, ChevronUp, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "@/components/ui/use-toast";
import { motion, AnimatePresence } from "framer-motion";

// ChatBot API key - in a real app, this would be stored securely on the server
const OPENAI_API_KEY = "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";

// Message types
interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

// StockSensei component
export default function StockSensei() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hello! I'm StockSensei, your AI trading assistant. How can I help you with stock-related questions today?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Scroll to bottom of chat when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen && !isMinimized) {
      inputRef.current?.focus();
    }
  }, [isOpen, isMinimized]);

  // Handle sending a message
  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message to chat
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date()
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      // Send message to OpenAI API
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [
            {
              role: "system",
              content: `You are StockSensei, an AI assistant specializing in stock market and financial education. 
              You provide concise, easy-to-understand answers to stock trading and investing questions.
              Keep your answers brief (100-150 words) and focused on stock-related topics only.
              If a question is not related to stocks, finance, investing, or trading, politely respond with:
              "I'm here to help with stock-related questions only!"
              Format your response with bullet points, bold text, or brief definitions when helpful.`
            },
            ...messages
              .filter(msg => msg.role !== "system")
              .map(msg => ({ role: msg.role, content: msg.content })),
            { role: "user", content: input }
          ],
          temperature: 0.7,
          max_tokens: 250
        })
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      const assistantResponse = data.choices[0].message.content;

      // Add assistant response to chat
      const assistantMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: assistantResponse,
        timestamp: new Date()
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error sending message to API:", error);
      
      // Add error message to chat
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: "I'm sorry, I encountered an error processing your request. Please try again later.",
        timestamp: new Date()
      };

      setMessages((prev) => [...prev, errorMessage]);
      
      toast({
        title: "Error",
        description: "Failed to connect to StockSensei. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Format message content with markdown-like styling
  const formatMessageContent = (content: string) => {
    // Bold text (replace **text** with <strong>text</strong>)
    let formattedContent = content.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
    
    // Bullet points
    formattedContent = formattedContent.replace(/^- (.*)$/gm, "<li>$1</li>");
    formattedContent = formattedContent.replace(/<li>(.*?)<\/li>/g, (match) => {
      return `<ul class="list-disc pl-5 my-2">${match}</ul>`;
    });
    
    // New lines
    formattedContent = formattedContent.replace(/\n/g, "<br />");
    
    return formattedContent;
  };

  return (
    <>
      {/* Chat Button */}
      {!isOpen && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-50"
                onClick={() => setIsOpen(true)}
              >
                <MessageSquare size={24} />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left">Ask StockSensei</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? "auto" : "500px"
            }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-6 right-6 w-80 md:w-96 z-50 shadow-xl"
          >
            <Card className="flex flex-col h-full overflow-hidden border-primary/50">
              {/* Chat Header */}
              <CardHeader className="px-4 py-3 flex flex-row items-center justify-between space-y-0 border-b">
                <div className="flex items-center">
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarImage src="/lovable-uploads/316a133f-dc61-4c53-ab60-4337c8837ead.png" />
                    <AvatarFallback>SS</AvatarFallback>
                  </Avatar>
                  <CardTitle className="text-base font-medium">StockSensei</CardTitle>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setIsMinimized(!isMinimized)}
                  >
                    {isMinimized ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setIsOpen(false)}
                  >
                    <X size={18} />
                  </Button>
                </div>
              </CardHeader>

              {/* Chat Content */}
              {!isMinimized && (
                <>
                  <CardContent className="flex-1 overflow-auto p-4 flex flex-col gap-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            message.role === "user"
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          }`}
                        >
                          <div 
                            className="text-sm"
                            dangerouslySetInnerHTML={{ __html: formatMessageContent(message.content) }}
                          />
                          <div className="text-xs opacity-70 mt-1">
                            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="max-w-[80%] rounded-lg p-3 bg-muted animate-pulse">
                          <div className="flex space-x-2">
                            <div className="h-2 w-2 rounded-full bg-current animate-bounce"></div>
                            <div className="h-2 w-2 rounded-full bg-current animate-bounce delay-150"></div>
                            <div className="h-2 w-2 rounded-full bg-current animate-bounce delay-300"></div>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </CardContent>

                  {/* Chat Input */}
                  <CardFooter className="p-3 border-t">
                    <form
                      className="flex w-full gap-2"
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleSendMessage();
                      }}
                    >
                      <Input
                        ref={inputRef}
                        placeholder="Ask about stocks, trading, investing..."
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        disabled={isLoading}
                        className="flex-1"
                      />
                      <Button
                        type="submit"
                        size="icon"
                        disabled={!input.trim() || isLoading}
                      >
                        <Send size={18} />
                      </Button>
                    </form>
                  </CardFooter>
                </>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
