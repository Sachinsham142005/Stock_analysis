
import { CreditCard, LogIn, Settings, ShoppingBag } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const activities = [
  {
    id: 1,
    type: "login",
    title: "Login from new device",
    details: "Windows PC - Chrome Browser",
    time: "Today, 10:45 AM",
    icon: LogIn
  },
  {
    id: 2,
    type: "transaction",
    title: "Purchased 10 shares of AAPL",
    details: "Transaction ID: #TX78945612",
    time: "Yesterday, 03:20 PM",
    icon: ShoppingBag
  },
  {
    id: 3,
    type: "payment",
    title: "Added $5,000 to account",
    details: "Payment method: **** 4582",
    time: "Apr 10, 2025, 11:30 AM",
    icon: CreditCard
  },
  {
    id: 4,
    type: "settings",
    title: "Updated security settings",
    details: "Changed password and enabled 2FA",
    time: "Apr 8, 2025, 09:15 AM",
    icon: Settings
  },
  {
    id: 5,
    type: "login",
    title: "Login from new location",
    details: "San Francisco, USA",
    time: "Apr 5, 2025, 07:45 PM",
    icon: LogIn
  }
];

export default function AccountActivity() {
  return (
    <Card className="w-full animate-fade-in">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <ActivityItem key={activity.id} activity={activity} index={index} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

interface ActivityProps {
  activity: {
    id: number;
    type: string;
    title: string;
    details: string;
    time: string;
    icon: React.ElementType;
  };
  index: number;
}

function ActivityItem({ activity, index }: ActivityProps) {
  const Icon = activity.icon;
  const delay = 0.1 + (index * 0.05);
  
  const getIconBackground = (type: string) => {
    switch (type) {
      case "login":
        return "bg-blue-100 text-blue-600";
      case "transaction":
        return "bg-green-100 text-green-600";
      case "payment":
        return "bg-purple-100 text-purple-600";
      case "settings":
        return "bg-amber-100 text-amber-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  return (
    <div 
      className="flex gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-all animate-in fade-in slide-in-from-bottom duration-300"
      style={{ animationDelay: `${delay}s` }}
    >
      <div className={`h-10 w-10 rounded-full ${getIconBackground(activity.type)} flex items-center justify-center shrink-0`}>
        <Icon size={18} />
      </div>
      <div className="flex-1">
        <h4 className="font-medium text-sm">{activity.title}</h4>
        <p className="text-xs text-muted-foreground mt-1">{activity.details}</p>
        <p className="text-xs text-muted-foreground mt-2">{activity.time}</p>
      </div>
    </div>
  );
}
