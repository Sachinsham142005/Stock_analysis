
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import LoginForm from "./LoginForm";
import SignupForm from "./SignupForm";

export default function AuthTabs() {
  const [activeTab, setActiveTab] = useState<string>("login");

  return (
    <div className="w-full max-w-md mx-auto animate-fade-in">
      <Tabs defaultValue="login" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="login" className="text-lg">Login</TabsTrigger>
          <TabsTrigger value="signup" className="text-lg">Sign Up</TabsTrigger>
        </TabsList>
        <div className="mt-4 overflow-hidden rounded-lg">
          <TabsContent 
            value="login" 
            className={`animate-slide-in-left ${activeTab === 'login' ? 'block' : 'hidden'}`}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Welcome Back</CardTitle>
                <CardDescription>
                  Enter your credentials to access your account
                </CardDescription>
              </CardHeader>
              <CardContent>
                <LoginForm />
              </CardContent>
              <CardFooter className="flex justify-center text-sm text-muted-foreground">
                <p>Trade Pulse - Your pulse on the market</p>
              </CardFooter>
            </Card>
          </TabsContent>
          <TabsContent 
            value="signup" 
            className={`animate-slide-in-right ${activeTab === 'signup' ? 'block' : 'hidden'}`}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Create an Account</CardTitle>
                <CardDescription>
                  Join thousands of traders on our platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <SignupForm />
              </CardContent>
              <CardFooter className="flex justify-center text-sm text-muted-foreground">
                <p>By signing up, you agree to our Terms and Privacy Policy</p>
              </CardFooter>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
