
import { useState } from "react";
import { ArrowUpDown, MoreHorizontal, ArrowUpRight, ArrowDownRight } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

// Sample portfolio data
const portfolioStocks = [
  { 
    id: 1, 
    symbol: "AAPL", 
    name: "Apple Inc.", 
    shares: 10, 
    avgPrice: 175.50, 
    currentPrice: 185.75, 
    value: 1857.50,
    sector: "Technology",
    change: 5.84,
    gainLoss: 102.50
  },
  { 
    id: 2, 
    symbol: "MSFT", 
    name: "Microsoft Corporation", 
    shares: 5, 
    avgPrice: 320.25, 
    currentPrice: 332.80, 
    value: 1664.00,
    sector: "Technology",
    change: 3.92,
    gainLoss: 62.75
  },
  { 
    id: 3, 
    symbol: "AMZN", 
    name: "Amazon.com Inc.", 
    shares: 8, 
    avgPrice: 142.50, 
    currentPrice: 138.75, 
    value: 1110.00,
    sector: "Consumer",
    change: -2.63,
    gainLoss: -30.00
  },
  { 
    id: 4, 
    symbol: "TSLA", 
    name: "Tesla Inc.", 
    shares: 6, 
    avgPrice: 210.75, 
    currentPrice: 230.45, 
    value: 1382.70,
    sector: "Consumer",
    change: 9.35,
    gainLoss: 118.20
  },
  { 
    id: 5, 
    symbol: "JNJ", 
    name: "Johnson & Johnson", 
    shares: 12, 
    avgPrice: 160.20, 
    currentPrice: 158.45, 
    value: 1901.40,
    sector: "Healthcare",
    change: -1.09,
    gainLoss: -21.00
  },
  { 
    id: 6, 
    symbol: "JPM", 
    name: "JPMorgan Chase & Co.", 
    shares: 15, 
    avgPrice: 142.30, 
    currentPrice: 153.85, 
    value: 2307.75,
    sector: "Finance",
    change: 8.12,
    gainLoss: 173.25
  },
  { 
    id: 7, 
    symbol: "XOM", 
    name: "Exxon Mobil Corporation", 
    shares: 20, 
    avgPrice: 105.50, 
    currentPrice: 112.25, 
    value: 2245.00,
    sector: "Energy",
    change: 6.40,
    gainLoss: 135.00
  }
];

export default function PortfolioTable() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortField, setSortField] = useState<keyof (typeof portfolioStocks)[0]>("symbol");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  // Handle sorting
  const handleSort = (field: keyof (typeof portfolioStocks)[0]) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  // Filter and sort data
  const filteredData = portfolioStocks
    .filter(stock => 
      stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) || 
      stock.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      
      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortDirection === "asc" 
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      } else {
        return sortDirection === "asc" 
          ? Number(aValue) - Number(bValue)
          : Number(bValue) - Number(aValue);
      }
    });

  // Calculate total portfolio value
  const totalValue = portfolioStocks.reduce((sum, stock) => sum + stock.value, 0);
  const totalGainLoss = portfolioStocks.reduce((sum, stock) => sum + stock.gainLoss, 0);
  const totalGainLossPercentage = (totalGainLoss / (totalValue - totalGainLoss)) * 100;

  return (
    <Card className="w-full animate-fade-in">
      <CardHeader className="pb-2">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle className="text-2xl font-bold">Your Holdings</CardTitle>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-sm text-muted-foreground">Total Value: <span className="font-semibold text-foreground">${totalValue.toLocaleString()}</span></p>
              <div className={`flex items-center gap-1 ${totalGainLoss >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {totalGainLoss >= 0 ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                <span className="text-xs font-medium">
                  ${Math.abs(totalGainLoss).toLocaleString()} ({Math.abs(totalGainLossPercentage).toFixed(2)}%)
                </span>
              </div>
            </div>
          </div>
          <div className="w-full sm:w-auto">
            <Input
              placeholder="Search holdings..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-[300px]"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead onClick={() => handleSort("symbol")} className="cursor-pointer">
                  <div className="flex items-center">
                    Symbol
                    <ArrowUpDown size={16} className="ml-1" />
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("name")} className="cursor-pointer">
                  <div className="flex items-center">
                    Name
                    <ArrowUpDown size={16} className="ml-1" />
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("shares")} className="cursor-pointer text-right">
                  <div className="flex items-center justify-end">
                    Shares
                    <ArrowUpDown size={16} className="ml-1" />
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("avgPrice")} className="cursor-pointer text-right">
                  <div className="flex items-center justify-end">
                    Avg Price
                    <ArrowUpDown size={16} className="ml-1" />
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("currentPrice")} className="cursor-pointer text-right">
                  <div className="flex items-center justify-end">
                    Current Price
                    <ArrowUpDown size={16} className="ml-1" />
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("value")} className="cursor-pointer text-right">
                  <div className="flex items-center justify-end">
                    Value
                    <ArrowUpDown size={16} className="ml-1" />
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("change")} className="cursor-pointer text-right">
                  <div className="flex items-center justify-end">
                    Change
                    <ArrowUpDown size={16} className="ml-1" />
                  </div>
                </TableHead>
                <TableHead className="w-[60px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="h-24 text-center">
                    No results found.
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map((stock, index) => (
                  <TableRow 
                    key={stock.id}
                    className="animate-in fade-in slide-in-from-left duration-300"
                    style={{ animationDelay: `${index * 0.05}s` }}
                  >
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {stock.symbol}
                        <Badge variant="outline" className="text-xs">
                          {stock.sector}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>{stock.name}</TableCell>
                    <TableCell className="text-right">{stock.shares}</TableCell>
                    <TableCell className="text-right">${stock.avgPrice.toFixed(2)}</TableCell>
                    <TableCell className="text-right">${stock.currentPrice.toFixed(2)}</TableCell>
                    <TableCell className="text-right font-medium">${stock.value.toLocaleString()}</TableCell>
                    <TableCell className="text-right">
                      <span className={stock.change >= 0 ? "text-green-500" : "text-red-500"}>
                        {stock.change >= 0 ? "+" : ""}{stock.change.toFixed(2)}%
                      </span>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal size={16} />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Buy More</DropdownMenuItem>
                          <DropdownMenuItem>Sell</DropdownMenuItem>
                          <DropdownMenuItem>View Details</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
