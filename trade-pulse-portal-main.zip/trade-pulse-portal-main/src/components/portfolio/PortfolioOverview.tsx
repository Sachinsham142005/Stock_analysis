
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

// Sample data for the portfolio
const portfolioData = [
  { name: "Technology", value: 45, color: "#6E44FF" },
  { name: "Healthcare", value: 20, color: "#FF7A30" },
  { name: "Finance", value: 15, color: "#1CE8B5" },
  { name: "Consumer", value: 10, color: "#2563EB" },
  { name: "Energy", value: 5, color: "#F59E0B" },
  { name: "Other", value: 5, color: "#8B5CF6" }
];

// Sample data for allocation
const allocationData = [
  { name: "Stocks", value: 65, color: "#6E44FF" },
  { name: "ETFs", value: 20, color: "#1CE8B5" },
  { name: "Bonds", value: 10, color: "#2563EB" },
  { name: "Cash", value: 5, color: "#F59E0B" }
];

export default function PortfolioOverview() {
  const [activeTab, setActiveTab] = useState("sectors");
  
  return (
    <Card className="w-full h-[400px] animate-fade-in">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-2xl font-bold">Portfolio Overview</CardTitle>
          <Tabs defaultValue="sectors" onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="sectors">Sectors</TabsTrigger>
              <TabsTrigger value="allocation">Allocation</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent className="h-[300px]">
        <div className="h-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={activeTab === "sectors" ? portfolioData : allocationData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={120}
                innerRadius={60}
                dataKey="value"
                animationDuration={1000}
                animationBegin={200}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {(activeTab === "sectors" ? portfolioData : allocationData).map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value) => [`${value}%`, "Percentage"]}
                contentStyle={{
                  backgroundColor: "rgba(0, 0, 0, 0.7)",
                  border: "none",
                  borderRadius: "4px",
                  color: "#fff",
                  fontSize: "12px",
                }}
              />
              <Legend verticalAlign="bottom" height={36} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
