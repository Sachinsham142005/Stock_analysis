
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import AppHeader from "./AppHeader";
import Sidebar from "./Sidebar";

interface AppLayoutProps {
  children: React.ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const navigate = useNavigate();

  // Check authentication
  useEffect(() => {
    const isLoggedIn = localStorage.getItem("tradePulse-loggedIn");
    if (!isLoggedIn) {
      navigate("/");
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      <div className="flex-1 pl-[70px] md:pl-[240px]">
        <AppHeader />
        <main className="pt-20 min-h-screen">
          {children}
        </main>
      </div>
    </div>
  );
}
