
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { 
  BarChart3, 
  ChevronLeft, 
  ChevronRight, 
  CreditCard, 
  Layers, 
  LineChart, 
  LayoutDashboard, 
  Newspaper, 
  Settings, 
  User,
  DollarSign,
  Star,
  Globe,
  TrendingUp,
  PlayCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface SidebarLink {
  icon: React.ElementType;
  label: string;
  href: string;
}

const mainLinks: SidebarLink[] = [
  {
    icon: LayoutDashboard,
    label: "Dashboard",
    href: "/dashboard",
  },
  {
    icon: LineChart,
    label: "Market",
    href: "/market",
  },
  {
    icon: Star,
    label: "Watchlist",
    href: "/watchlist",
  },
  {
    icon: TrendingUp,
    label: "Analysis",
    href: "/analysis",
  },
  {
    icon: DollarSign,
    label: "Currency Converter",
    href: "/currency-converter",
  },
  {
    icon: CreditCard,
    label: "Portfolio",
    href: "/portfolio",
  },
  {
    icon: PlayCircle,
    label: "Demo",
    href: "/demo",
  },
  {
    icon: Newspaper,
    label: "News",
    href: "/news",
  },
];

const secondaryLinks: SidebarLink[] = [
  {
    icon: User,
    label: "Profile",
    href: "/profile",
  },
  {
    icon: Settings,
    label: "Settings",
    href: "/settings",
  },
];

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  return (
    <aside 
      className={cn(
        "fixed left-0 top-0 bottom-0 z-40 flex flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border transition-all duration-300 ease-in-out pt-16",
        collapsed ? "w-[70px]" : "w-[240px]"
      )}
    >
      <div className="flex-1 flex flex-col gap-2 p-3 overflow-y-auto scrollbar-none">
        <nav className="space-y-2">
          {mainLinks.map((link) => (
            <NavLink
              key={link.href}
              {...link}
              active={location.pathname === link.href}
              collapsed={collapsed}
            />
          ))}
        </nav>

        <div className="mt-4 pt-4 border-t border-sidebar-border">
          <h3 className={cn(
            "text-xs uppercase text-sidebar-foreground/50 px-3 mb-2 transition-opacity",
            collapsed ? "opacity-0" : "opacity-100"
          )}>
            Account
          </h3>
          <nav className="space-y-2">
            {secondaryLinks.map((link) => (
              <NavLink
                key={link.href}
                {...link}
                active={location.pathname === link.href}
                collapsed={collapsed}
              />
            ))}
          </nav>
        </div>
      </div>

      <Button
        variant="outline"
        size="icon"
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 h-6 w-6 rounded-full border border-sidebar-border bg-background text-foreground shadow-md z-50 p-0"
      >
        {collapsed ? (
          <ChevronRight className="h-3 w-3" />
        ) : (
          <ChevronLeft className="h-3 w-3" />
        )}
      </Button>
    </aside>
  );
}

function NavLink({ 
  icon: Icon, 
  label, 
  href, 
  active, 
  collapsed 
}: SidebarLink & { active: boolean; collapsed: boolean }) {
  return (
    <TooltipProvider delayDuration={0} disableHoverableContent>
      <Tooltip>
        <TooltipTrigger asChild>
          <Link
            to={href}
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-md transition-all group relative overflow-hidden",
              active 
                ? "bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90" 
                : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground text-sidebar-foreground/80"
            )}
          >
            <div className="relative z-10">
              <Icon size={20} />
            </div>
            <span className={cn(
              "text-sm font-medium whitespace-nowrap transition-all duration-300",
              collapsed ? "opacity-0 translate-x-2 invisible absolute" : "opacity-100"
            )}>
              {label}
            </span>
            {active && (
              <div className="absolute inset-0 opacity-20 bg-white/10 animate-pulse"></div>
            )}
          </Link>
        </TooltipTrigger>
        {collapsed && (
          <TooltipContent side="right" className="bg-sidebar text-sidebar-foreground border-sidebar-border">
            {label}
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );
}
