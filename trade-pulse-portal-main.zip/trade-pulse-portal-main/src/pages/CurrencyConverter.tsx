import { useState, useEffect } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { ArrowLeftRight, BarChart3, ChevronDown, ChevronUp, Repeat, TrendingUp } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, Legend } from "recharts";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

// Sample currency data
const currencies = [
  { code: "USD", name: "US Dollar", flag: "🇺🇸" },
  { code: "EUR", name: "Euro", flag: "🇪🇺" },
  { code: "GBP", name: "British Pound", flag: "🇬🇧" },
  { code: "JPY", name: "Japanese Yen", flag: "🇯🇵" },
  { code: "AUD", name: "Australian Dollar", flag: "🇦🇺" },
  { code: "CAD", name: "Canadian Dollar", flag: "🇨🇦" },
  { code: "CHF", name: "Swiss Franc", flag: "🇨🇭" },
  { code: "CNY", name: "Chinese Yuan", flag: "🇨🇳" },
  { code: "INR", name: "Indian Rupee", flag: "🇮🇳" },
  { code: "SGD", name: "Singapore Dollar", flag: "🇸🇬" },
  { code: "NZD", name: "New Zealand Dollar", flag: "🇳🇿" },
  { code: "BRL", name: "Brazilian Real", flag: "🇧🇷" },
  { code: "ZAR", name: "South African Rand", flag: "🇿🇦" },
  { code: "HKD", name: "Hong Kong Dollar", flag: "🇭🇰" },
  { code: "SEK", name: "Swedish Krona", flag: "🇸🇪" },
];

// Sample exchange rates (relative to USD)
const exchangeRates = {
  "USD": 1,
  "EUR": 0.92,
  "GBP": 0.78,
  "JPY": 150.65,
  "AUD": 1.52,
  "CAD": 1.35,
  "CHF": 0.89,
  "CNY": 7.24,
  "INR": 83.12,
  "SGD": 1.34,
  "NZD": 1.64,
  "BRL": 5.06,
  "ZAR": 18.42,
  "HKD": 7.82,
  "SEK": 10.43,
};

// Sample historical data for currency chart
const generateHistoricalData = (fromCurrency, toCurrency) => {
  const baseRate = exchangeRates[toCurrency] / exchangeRates[fromCurrency];
  const dates = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  
  return dates.map((month, index) => {
    // Create some random variation
    const randomFactor = 0.95 + Math.random() * 0.1; // Between 0.95 and 1.05
    return {
      name: month,
      rate: parseFloat((baseRate * randomFactor).toFixed(4))
    };
  });
};

export default function CurrencyConverter() {
  const [amount, setAmount] = useState(1);
  const [fromCurrency, setFromCurrency] = useState("USD");
  const [toCurrency, setToCurrency] = useState("EUR");
  const [result, setResult] = useState(0);
  const [historicalData, setHistoricalData] = useState([]);
  const [showChart, setShowChart] = useState(false);
  
  // Calculate conversion when inputs change
  useEffect(() => {
    if (fromCurrency && toCurrency) {
      const fromRate = exchangeRates[fromCurrency];
      const toRate = exchangeRates[toCurrency];
      const calculatedResult = (amount * toRate) / fromRate;
      setResult(calculatedResult);
      
      // Generate historical data for the chart
      setHistoricalData(generateHistoricalData(fromCurrency, toCurrency));
    }
  }, [amount, fromCurrency, toCurrency]);
  
  // Swap currencies
  const handleSwapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };
  
  // Format currency for display
  const formatCurrency = (value, currency) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 6
    }).format(value);
  };

  return (
    <AppLayout>
      <div className="p-6 space-y-6 animate-fade-in">
        <div>
          <h1 className="text-3xl font-bold">Currency Converter</h1>
          <p className="text-muted-foreground">Convert between different currencies with real-time exchange rates</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Currency Converter</CardTitle>
              <CardDescription>
                Enter an amount and select currencies to convert between
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="amount">Amount</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                    className="text-lg"
                  />
                </div>
                
                <div className="grid grid-cols-[1fr,auto,1fr] items-end gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fromCurrency">From</Label>
                    <Select value={fromCurrency} onValueChange={setFromCurrency}>
                      <SelectTrigger id="fromCurrency">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        {currencies.map((currency) => (
                          <SelectItem key={currency.code} value={currency.code}>
                            <div className="flex items-center gap-2">
                              <span>{currency.flag}</span>
                              <span>{currency.code} - {currency.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button 
                    variant="outline" 
                    size="icon" 
                    onClick={handleSwapCurrencies}
                    className="h-10 w-10 rounded-full border-dashed animate-pulse"
                  >
                    <ArrowLeftRight className="h-4 w-4" />
                  </Button>
                  
                  <div className="space-y-2">
                    <Label htmlFor="toCurrency">To</Label>
                    <Select value={toCurrency} onValueChange={setToCurrency}>
                      <SelectTrigger id="toCurrency">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        {currencies.map((currency) => (
                          <SelectItem key={currency.code} value={currency.code}>
                            <div className="flex items-center gap-2">
                              <span>{currency.flag}</span>
                              <span>{currency.code} - {currency.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              <div className="pt-6 border-t">
                <div className="text-center">
                  <div className="text-muted-foreground text-sm mb-2">
                    {amount} {fromCurrency} equals
                  </div>
                  <div className="text-3xl font-bold">
                    {formatCurrency(result, toCurrency)}
                  </div>
                  <div className="text-sm text-muted-foreground mt-2">
                    1 {fromCurrency} = {(exchangeRates[toCurrency] / exchangeRates[fromCurrency]).toFixed(6)} {toCurrency}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center">
                <Button
                  variant="outline"
                  onClick={() => setShowChart(!showChart)}
                  className="gap-2"
                >
                  {showChart ? (
                    <>
                      <ChevronUp className="h-4 w-4" />
                      Hide Historical Chart
                    </>
                  ) : (
                    <>
                      <ChevronDown className="h-4 w-4" />
                      Show Historical Chart
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Currency Information</CardTitle>
              <CardDescription>
                Details and trends for selected currencies
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2 border rounded-lg p-4">
                  <div className="flex items-center gap-2">
                    <div className="text-2xl">
                      {currencies.find(c => c.code === fromCurrency)?.flag}
                    </div>
                    <div>
                      <h3 className="font-medium">{fromCurrency}</h3>
                      <p className="text-xs text-muted-foreground">
                        {currencies.find(c => c.code === fromCurrency)?.name}
                      </p>
                    </div>
                  </div>
                  <div className="text-sm mt-2">
                    <div className="flex justify-between">
                      <span>Base value:</span>
                      <span>{(1 / exchangeRates[fromCurrency]).toFixed(4)} USD</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2 border rounded-lg p-4">
                  <div className="flex items-center gap-2">
                    <div className="text-2xl">
                      {currencies.find(c => c.code === toCurrency)?.flag}
                    </div>
                    <div>
                      <h3 className="font-medium">{toCurrency}</h3>
                      <p className="text-xs text-muted-foreground">
                        {currencies.find(c => c.code === toCurrency)?.name}
                      </p>
                    </div>
                  </div>
                  <div className="text-sm mt-2">
                    <div className="flex justify-between">
                      <span>Base value:</span>
                      <span>{(1 / exchangeRates[toCurrency]).toFixed(4)} USD</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-lg p-4">
                <h3 className="text-sm font-medium flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4" />
                  Exchange Rate Trend
                </h3>
                <div className="flex items-center justify-between text-sm mb-4">
                  <span>{fromCurrency} to {toCurrency} over time</span>
                  <div className="flex items-center gap-1">
                    <Badge variant="outline">Last 12 months</Badge>
                  </div>
                </div>
                
                {showChart && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 300 }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="h-[300px]"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={historicalData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis 
                          domain={['auto', 'auto']}
                          tickFormatter={(value) => {
                            // Handle the case where value might be a string
                            return typeof value === 'number' ? value.toFixed(2) : value;
                          }}
                        />
                        <RechartsTooltip 
                          formatter={(value) => {
                            // Handle the case where value might be a string
                            return [
                              typeof value === 'number' ? value.toFixed(4) : value,
                              `Exchange Rate (${fromCurrency}/${toCurrency})`
                            ];
                          }}
                        />
                        <Line
                          type="monotone"
                          dataKey="rate"
                          stroke="#8884d8"
                          activeDot={{ r: 8 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </motion.div>
                )}
              </div>
              
              <div className="border rounded-lg p-4">
                <h3 className="text-sm font-medium flex items-center gap-2 mb-2">
                  <BarChart3 className="h-4 w-4" />
                  Popular Conversions
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center">
                    <span>1 USD = {exchangeRates.EUR.toFixed(4)} EUR</span>
                    <Button variant="ghost" size="sm" className="h-7">Convert</Button>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>1 EUR = {(exchangeRates.USD / exchangeRates.EUR).toFixed(4)} USD</span>
                    <Button variant="ghost" size="sm" className="h-7">Convert</Button>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>1 GBP = {(exchangeRates.USD / exchangeRates.GBP).toFixed(4)} USD</span>
                    <Button variant="ghost" size="sm" className="h-7">Convert</Button>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>1 USD = {exchangeRates.JPY.toFixed(4)} JPY</span>
                    <Button variant="ghost" size="sm" className="h-7">Convert</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
