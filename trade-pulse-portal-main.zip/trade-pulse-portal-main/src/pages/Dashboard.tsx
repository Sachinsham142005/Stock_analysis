
import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import StatsGrid from "@/components/dashboard/StatsGrid";
import MainChart from "@/components/dashboard/MainChart";
import StockCard from "@/components/dashboard/StockCard";
import NewsFeed from "@/components/dashboard/NewsFeed";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search } from "lucide-react";

// Sample stock data
const stocks = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 185.75,
    change: 4.25,
    changePercent: 2.35,
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 175 + Math.random() * 15 }))
  },
  {
    symbol: "MSFT",
    name: "Microsoft Corporation",
    price: 332.80,
    change: 5.15,
    changePercent: 1.57,
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 320 + Math.random() * 20 }))
  },
  {
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    price: 138.75,
    change: -2.25,
    changePercent: -1.59,
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 135 + Math.random() * 10 }))
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    price: 148.15,
    change: 2.05,
    changePercent: 1.40,
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 140 + Math.random() * 12 }))
  },
  {
    symbol: "TSLA",
    name: "Tesla Inc.",
    price: 230.45,
    change: 8.75,
    changePercent: 3.95,
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 220 + Math.random() * 15 }))
  },
  {
    symbol: "META",
    name: "Meta Platforms Inc.",
    price: 435.20,
    change: 7.30,
    changePercent: 1.70,
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 420 + Math.random() * 20 }))
  },
  {
    symbol: "NFLX",
    name: "Netflix Inc.",
    price: 605.75,
    change: -12.25,
    changePercent: -1.98,
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 590 + Math.random() * 30 }))
  },
  {
    symbol: "JPM",
    name: "JPMorgan Chase & Co.",
    price: 153.85,
    change: 1.65,
    changePercent: 1.09,
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 150 + Math.random() * 8 }))
  }
];

// Stock categories for filtering
const categories = [
  "All", "Technology", "Finance", "Healthcare", "Energy", "Consumer", "Communication"
];

export default function Dashboard() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  // Filter stocks based on search and category
  const filteredStocks = stocks.filter(stock => {
    const matchesSearch = stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          stock.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // For demo purposes, we'll assign a simple category based on the symbol
    let category = "Technology"; // Default
    if (["JPM", "V", "BAC"].includes(stock.symbol)) category = "Finance";
    if (["JNJ", "UNH", "PFE"].includes(stock.symbol)) category = "Healthcare";
    if (["XOM", "CVX"].includes(stock.symbol)) category = "Energy";
    if (["AMZN", "TSLA"].includes(stock.symbol)) category = "Consumer";
    if (["GOOGL", "META"].includes(stock.symbol)) category = "Communication";
    
    const matchesCategory = activeCategory === "All" || category === activeCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <AppLayout>
      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <StatsGrid />
        
        {/* Main Chart */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <MainChart />
          </div>
          <div>
            <NewsFeed />
          </div>
        </div>
        
        {/* Stocks Section */}
        <Card className="animate-fade-in">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="text-2xl font-bold">Top Stocks</CardTitle>
              <div className="relative max-w-xs w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input 
                  placeholder="Search stocks..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 pr-4"
                />
              </div>
            </div>
            
            <div className="flex gap-2 overflow-x-auto py-3 scrollbar-none">
              {categories.map(category => (
                <Badge 
                  key={category} 
                  variant={activeCategory === category ? "default" : "outline"} 
                  className="cursor-pointer transition-all hover:opacity-80 whitespace-nowrap"
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredStocks.length === 0 ? (
                <div className="col-span-full text-center py-8 text-muted-foreground">
                  No stocks found matching your criteria.
                </div>
              ) : (
                filteredStocks.map((stock, index) => (
                  <StockCard 
                    key={stock.symbol} 
                    {...stock} 
                  />
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
