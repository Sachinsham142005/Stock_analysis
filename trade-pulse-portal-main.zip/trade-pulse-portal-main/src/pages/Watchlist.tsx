
import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { 
  ArrowDownRight, 
  ArrowUpRight, 
  Bell, 
  Download, 
  ExternalLink, 
  MoreHorizontal, 
  Plus, 
  Search, 
  Trash2 
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { LineChart, Line, ResponsiveContainer } from "recharts";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";

// Sample watchlist data
const watchlistData = [
  {
    id: "1",
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 175.32,
    change: 2.35,
    changePercent: 1.35,
    volume: "34.5M",
    marketCap: "2.85T",
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 165 + Math.random() * 15 })),
    alerts: true
  },
  {
    id: "2",
    symbol: "MSFT",
    name: "Microsoft Corporation",
    price: 328.79,
    change: 4.23,
    changePercent: 1.29,
    volume: "22.1M",
    marketCap: "2.44T",
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 320 + Math.random() * 15 })),
    alerts: false
  },
  {
    id: "3",
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    price: 145.68,
    change: -1.23,
    changePercent: -0.84,
    volume: "18.3M",
    marketCap: "1.85T",
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 140 + Math.random() * 10 })),
    alerts: true
  },
  {
    id: "4",
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    price: 136.71,
    change: 0.89,
    changePercent: 0.65,
    volume: "30.2M",
    marketCap: "1.41T",
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 130 + Math.random() * 10 })),
    alerts: false
  },
  {
    id: "5",
    symbol: "TSLA",
    name: "Tesla Inc.",
    price: 233.10,
    change: -5.14,
    changePercent: -2.16,
    volume: "37.9M",
    marketCap: "741.2B",
    chartData: Array.from({ length: 20 }, (_, i) => ({ value: 230 + Math.random() * 15 })),
    alerts: true
  }
];

export default function Watchlist() {
  const [stocks, setStocks] = useState(watchlistData);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Filter stocks based on search
  const filteredStocks = stocks.filter(stock => 
    stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) || 
    stock.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Toggle alerts for a stock
  const toggleAlert = (id: string) => {
    setStocks(stocks.map(stock => 
      stock.id === id ? { ...stock, alerts: !stock.alerts } : stock
    ));
    
    const stock = stocks.find(s => s.id === id);
    if (stock) {
      toast({
        title: stock.alerts ? "Alerts disabled" : "Alerts enabled",
        description: `Price alerts for ${stock.symbol} have been ${stock.alerts ? "disabled" : "enabled"}.`,
      });
    }
  };
  
  // Remove stock from watchlist
  const removeStock = (id: string) => {
    const stockToRemove = stocks.find(s => s.id === id);
    setStocks(stocks.filter(stock => stock.id !== id));
    
    if (stockToRemove) {
      toast({
        title: "Removed from Watchlist",
        description: `${stockToRemove.symbol} has been removed from your watchlist.`,
      });
    }
  };
  
  // Export watchlist to CSV
  const exportToCSV = () => {
    // Create CSV content
    const headers = ['Symbol', 'Name', 'Price', 'Change', 'Change %', 'Volume', 'Market Cap'];
    const csvContent = [
      headers.join(','),
      ...stocks.map(stock => [
        stock.symbol,
        `"${stock.name}"`, // Use quotes to handle commas in names
        stock.price,
        stock.change,
        `${stock.changePercent}%`,
        stock.volume,
        stock.marketCap
      ].join(','))
    ].join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'watchlist.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Watchlist Exported",
      description: "Your watchlist has been exported as a CSV file.",
    });
  };

  return (
    <AppLayout>
      <div className="p-6 space-y-6 animate-fade-in">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Watchlist</h1>
            <p className="text-muted-foreground">Track your favorite stocks</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative w-full md:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Search watchlist..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 pr-4 w-full md:w-[250px]"
              />
            </div>
            <Button className="gap-2" onClick={exportToCSV}>
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>My Watchlist</CardTitle>
            <CardDescription>
              Track performance and set alerts for stocks you're interested in
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredStocks.length === 0 ? (
              <div className="text-center py-10 bg-muted/20 rounded-lg">
                <div className="mx-auto w-16 h-16 flex items-center justify-center rounded-full bg-muted/50 mb-4">
                  <Plus className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium mb-2">Your watchlist is empty</h3>
                <p className="text-muted-foreground mb-4">
                  Add stocks from the Market page to start tracking them
                </p>
                <Button>Go to Market</Button>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Symbol</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Chart</TableHead>
                      <TableHead className="text-right">Price</TableHead>
                      <TableHead className="text-right">Change</TableHead>
                      <TableHead className="text-center">Alerts</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStocks.map((stock) => {
                      const isPositive = stock.change >= 0;
                      
                      return (
                        <TableRow key={stock.id}>
                          <TableCell className="font-medium">{stock.symbol}</TableCell>
                          <TableCell>{stock.name}</TableCell>
                          <TableCell className="w-[100px]">
                            <div className="h-10">
                              <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={stock.chartData}>
                                  <Line 
                                    type="monotone" 
                                    dataKey="value" 
                                    stroke={isPositive ? '#10b981' : '#ef4444'} 
                                    strokeWidth={1.5} 
                                    dot={false}
                                  />
                                </LineChart>
                              </ResponsiveContainer>
                            </div>
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            ${stock.price.toFixed(2)}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className={`flex items-center justify-end gap-1 ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                              {isPositive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                              <span>{isPositive ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex justify-center">
                              <Switch 
                                checked={stock.alerts} 
                                onCheckedChange={() => toggleAlert(stock.id)} 
                              />
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem className="cursor-pointer gap-2">
                                  <ExternalLink className="h-4 w-4" />
                                  <span>View Details</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem className="cursor-pointer gap-2">
                                  <Bell className="h-4 w-4" />
                                  <span>Set Price Alert</span>
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem 
                                  className="cursor-pointer text-destructive focus:text-destructive gap-2"
                                  onClick={() => removeStock(stock.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                  <span>Remove</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
