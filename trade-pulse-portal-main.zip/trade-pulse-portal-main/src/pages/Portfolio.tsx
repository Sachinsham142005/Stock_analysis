
import AppLayout from "@/components/layout/AppLayout";
import PortfolioOverview from "@/components/portfolio/PortfolioOverview";
import PortfolioTable from "@/components/portfolio/PortfolioTable";

export default function Portfolio() {
  return (
    <AppLayout>
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <PortfolioOverview />
          
          <div className="h-[400px] grid grid-cols-1 lg:grid-cols-2 gap-4">
            <PerformanceCard 
              title="Total Return" 
              value="+15.8%" 
              timeframe="All Time"
              trend="up"
              description="Your portfolio has outperformed the S&P 500 by 3.2%"
            />
            <PerformanceCard 
              title="Dividend Yield" 
              value="2.4%" 
              timeframe="Annual Rate"
              trend="up"
              description="Next dividend payment estimated in 15 days"
            />
            <PerformanceCard 
              title="Realized Gain" 
              value="$3,256.42" 
              timeframe="This Year"
              trend="up"
              description="Up from $2,845.10 last year"
            />
            <PerformanceCard 
              title="Unrealized Gain" 
              value="$5,830.25" 
              timeframe="Current"
              trend="up"
              description="Increased by $420.15 today"
            />
          </div>
        </div>
        
        <PortfolioTable />
      </div>
    </AppLayout>
  );
}

interface PerformanceCardProps {
  title: string;
  value: string;
  timeframe: string;
  trend: "up" | "down";
  description: string;
}

function PerformanceCard({ title, value, timeframe, trend, description }: PerformanceCardProps) {
  return (
    <div className="bg-card rounded-lg border border-border p-4 hover:shadow-md transition-all animate-fade-in animate-in duration-300">
      <div className="flex flex-col h-full">
        <div className="mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
          <div className="flex items-baseline gap-2">
            <p className={`text-2xl font-bold ${trend === "up" ? "text-green-500" : "text-red-500"}`}>
              {value}
            </p>
            <span className="text-xs text-muted-foreground">{timeframe}</span>
          </div>
        </div>
        <div className="flex-1 flex items-end">
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>
    </div>
  );
}
