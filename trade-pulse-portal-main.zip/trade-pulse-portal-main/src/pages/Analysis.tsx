
import { useState, useRef } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from "recharts";
import { FileText, Upload, AlertCircle, BarChart } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "@/components/ui/use-toast";

// Type for CSV data
interface CsvData {
  columns: string[];
  rows: any[];
  summary: {
    min: Record<string, number>;
    max: Record<string, number>;
    mean: Record<string, number>;
    median: Record<string, number>;
    volatility?: number;
    performance?: number;
    dataPoints?: number;
  } | null;
}

export default function Analysis() {
  const [csvData, setCsvData] = useState<CsvData>({ columns: [], rows: [], summary: null });
  const [error, setError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [chartType, setChartType] = useState("line");
  const [selectedColumn, setSelectedColumn] = useState("");
  const [fileName, setFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Function to handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.type !== "text/csv" && !file.name.endsWith('.csv')) {
      setError("Please upload a valid CSV file");
      toast({
        title: "Invalid File",
        description: "Please upload a valid CSV file with stock data.",
        variant: "destructive"
      });
      return;
    }
    
    setFileName(file.name);
    
    // Read the file
    const reader = new FileReader();
    reader.onload = (event) => {
      const csvContent = event.target?.result as string;
      processCSV(csvContent);
    };
    reader.onerror = () => {
      setError("Error reading the file");
      toast({
        title: "Error",
        description: "Failed to read the file. Please try again.",
        variant: "destructive"
      });
    };
    reader.readAsText(file);
  };
  
  // Process CSV content
  const processCSV = (content: string) => {
    setIsAnalyzing(true);
    
    try {
      // Simple CSV parsing (could be enhanced with a library in production)
      const lines = content.split('\n');
      const headers = lines[0].split(',').map(h => h.trim());
      
      const rows = [];
      for (let i = 1; i < lines.length; i++) {
        if (lines[i].trim() === '') continue;
        
        const values = lines[i].split(',').map(v => v.trim());
        const row: Record<string, any> = {};
        
        headers.forEach((header, index) => {
          // Try to convert numeric values
          const value = values[index];
          row[header] = isNaN(Number(value)) ? value : Number(value);
        });
        
        rows.push(row);
      }
      
      if (rows.length === 0) {
        throw new Error("No valid data found in the CSV file");
      }
      
      // Calculate basic statistics for numeric columns
      const numericColumns = headers.filter(header => 
        typeof rows[0][header] === 'number'
      );
      
      if (numericColumns.length === 0) {
        throw new Error("No numeric columns found in the CSV file");
      }
      
      const summary: CsvData['summary'] = {
        min: {},
        max: {},
        mean: {},
        median: {},
        volatility: 0,
        performance: 0,
        dataPoints: rows.length
      };
      
      numericColumns.forEach(column => {
        const values = rows.map(row => row[column]).filter(v => !isNaN(v));
        
        if (values.length === 0) return;
        
        summary.min[column] = Math.min(...values);
        summary.max[column] = Math.max(...values);
        summary.mean[column] = values.reduce((sum, val) => sum + val, 0) / values.length;
        
        // Calculate median
        const sortedValues = [...values].sort((a, b) => a - b);
        const mid = Math.floor(sortedValues.length / 2);
        summary.median[column] = sortedValues.length % 2 === 0 
          ? (sortedValues[mid - 1] + sortedValues[mid]) / 2
          : sortedValues[mid];
          
        // Set initial column for visualization
        if (!selectedColumn) setSelectedColumn(column);
      });
      
      // Calculate volatility (standard deviation of price)
      const priceColumn = numericColumns.find(col => 
        col.toLowerCase().includes('price') || 
        col.toLowerCase().includes('close') || 
        col.toLowerCase().includes('value')
      ) || numericColumns[0];
      
      if (priceColumn) {
        const prices = rows.map(row => row[priceColumn]);
        const mean = summary.mean[priceColumn];
        const squaredDiffs = prices.map(price => Math.pow(price - mean, 2));
        const variance = squaredDiffs.reduce((sum, val) => sum + val, 0) / prices.length;
        summary.volatility = Math.sqrt(variance);
        
        // Calculate performance (percentage change from first to last)
        const firstPrice = prices[0];
        const lastPrice = prices[prices.length - 1];
        summary.performance = ((lastPrice - firstPrice) / firstPrice) * 100;
        
        // Set the price column as the default selected column
        setSelectedColumn(priceColumn);
      }
      
      setCsvData({ columns: headers, rows, summary });
      setIsAnalyzing(false);
      
      toast({
        title: "Analysis Complete",
        description: `Successfully analyzed ${rows.length} data points.`,
      });
    } catch (error) {
      console.error("Error processing CSV:", error);
      setError(error instanceof Error ? error.message : "Error processing the CSV file");
      setIsAnalyzing(false);
      
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "Error processing the CSV file. Please check the format.",
        variant: "destructive"
      });
    }
  };
  
  // Format currency values
  const formatCurrency = (value: number) => {
    if (typeof value !== 'number') return '$0.00';
    return `$${value.toFixed(2)}`;
  };
  
  // Format date values
  const formatDate = (value: string) => {
    if (!value) return '';
    
    // Try to parse as date if it looks like one
    if (value.includes('-') || value.includes('/')) {
      try {
        const date = new Date(value);
        return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
      } catch {
        return value.substring(0, 5);
      }
    }
    return String(value).substring(0, 5);
  };
  
  // Handle analyze button click
  const handleAnalyze = () => {
    if (!fileName) {
      setError("Please upload a CSV file first");
      toast({
        title: "No File Selected",
        description: "Please upload a CSV file first.",
        variant: "destructive"
      });
      return;
    }
    
    // If we already have data, just trigger the analysis display
    if (csvData.rows.length > 0 && csvData.summary) {
      toast({
        title: "Analysis Ready",
        description: "Data has already been analyzed.",
      });
      return;
    }
  };

  return (
    <AppLayout>
      <div className="p-6 space-y-6 bg-[#1A1F2C] min-h-screen">
        <Card className="bg-[#1A1F2C] border-[#2A2F3C] text-white">
          <CardContent className="p-8">
            <div className="flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-16 h-16 rounded-full border-2 border-dashed border-blue-400 flex items-center justify-center">
                <FileText className="h-8 w-8 text-blue-400" />
              </div>
              <h2 className="text-xl font-semibold">Import CSV Stock Data</h2>
              <p className="text-gray-400 max-w-md">
                Upload a CSV file with date and price columns to analyze stock performance
              </p>
              
              <Button 
                onClick={() => fileInputRef.current?.click()}
                className="bg-blue-500 hover:bg-blue-600 text-white mt-4"
                size="lg"
              >
                <Upload className="mr-2 h-4 w-4" />
                Select CSV File
              </Button>
              
              <Input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                className="hidden"
                onChange={handleFileUpload}
              />
              
              {fileName && (
                <div className="flex items-center gap-4 mt-2">
                  <span className="text-gray-300">{fileName}</span>
                  <Button 
                    onClick={handleAnalyze}
                    variant="secondary"
                    className="gap-2"
                  >
                    <BarChart className="h-4 w-4" />
                    Analyze
                  </Button>
                </div>
              )}
              
              {/* Error Message */}
              {error && (
                <Alert variant="destructive" className="mt-4 bg-red-900/20 border-red-800">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Analysis Results */}
        {isAnalyzing ? (
          <div className="py-8 text-center text-white">
            <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p>Analyzing CSV data...</p>
          </div>
        ) : csvData.rows.length > 0 && csvData.summary ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <Card className="bg-[#1A1F2C] border-[#2A2F3C] text-white">
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="flex items-center gap-2">
                    <BarChart className="h-5 w-5" />
                    <h2 className="text-xl font-semibold">Analysis Results for {fileName}</h2>
                  </div>
                  <p className="text-gray-400">Based on {csvData.summary.dataPoints} data points</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Average Price */}
                    <div className="bg-[#1B2134] p-4 rounded-lg">
                      <p className="text-gray-400 mb-2">Average Price</p>
                      <p className="text-2xl font-mono">
                        {formatCurrency(csvData.summary.mean[selectedColumn] || 0)}
                      </p>
                    </div>
                    
                    {/* Min Price */}
                    <div className="bg-[#1B2134] p-4 rounded-lg">
                      <p className="text-gray-400 mb-2">Min Price</p>
                      <p className="text-2xl font-mono">
                        {formatCurrency(csvData.summary.min[selectedColumn] || 0)}
                      </p>
                    </div>
                    
                    {/* Max Price */}
                    <div className="bg-[#1B2134] p-4 rounded-lg">
                      <p className="text-gray-400 mb-2">Max Price</p>
                      <p className="text-2xl font-mono">
                        {formatCurrency(csvData.summary.max[selectedColumn] || 0)}
                      </p>
                    </div>
                    
                    {/* Volatility */}
                    <div className="bg-[#1B2134] p-4 rounded-lg">
                      <p className="text-gray-400 mb-2">Volatility</p>
                      <p className="text-2xl font-mono">
                        {formatCurrency(csvData.summary.volatility || 0)}
                      </p>
                    </div>
                  </div>
                  
                  {/* Performance */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <p className="text-gray-400">Performance</p>
                      <p className={`text-sm font-mono ${csvData.summary.performance && csvData.summary.performance > 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {csvData.summary.performance ? (csvData.summary.performance > 0 ? '+' : '') + csvData.summary.performance.toFixed(2) + '%' : '0.00%'}
                      </p>
                    </div>
                    
                    <div className="bg-[#141828] p-4 rounded-lg h-[300px]">
                      <div className="flex justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <p className="text-gray-400 text-sm">Data Column:</p>
                          <select 
                            className="bg-[#1B2134] border border-gray-700 text-white text-sm rounded-md p-1"
                            value={selectedColumn}
                            onChange={(e) => setSelectedColumn(e.target.value)}
                          >
                            {csvData.columns
                              .filter(col => typeof csvData.rows[0][col] === 'number')
                              .map(col => (
                                <option key={col} value={col}>{col}</option>
                              ))
                            }
                          </select>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant={chartType === "line" ? "default" : "outline"}
                            onClick={() => setChartType("line")}
                            className={chartType === "line" ? "bg-blue-500" : "bg-transparent text-white border-gray-600"}
                          >
                            Line
                          </Button>
                          <Button
                            size="sm"
                            variant={chartType === "area" ? "default" : "outline"}
                            onClick={() => setChartType("area")}
                            className={chartType === "area" ? "bg-blue-500" : "bg-transparent text-white border-gray-600"}
                          >
                            Area
                          </Button>
                        </div>
                      </div>
                      
                      <ResponsiveContainer width="100%" height="100%">
                        {chartType === "line" ? (
                          <LineChart data={csvData.rows}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#333" />
                            <XAxis 
                              dataKey={csvData.columns[0]} 
                              tick={{ fill: '#999' }} 
                              stroke="#444"
                              tickFormatter={(value) => formatDate(value)}
                            />
                            <YAxis 
                              tick={{ fill: '#999' }} 
                              stroke="#444"
                              domain={['auto', 'auto']}
                            />
                            <Tooltip 
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  return (
                                    <div className="bg-[#1A1F2C] border border-[#2A2F3C] p-2 text-xs">
                                      <p className="font-bold text-white">{payload[0].payload[csvData.columns[0]]}</p>
                                      <p className="text-[#9b87f5]">{`${selectedColumn}: ${formatCurrency(payload[0].value as number)}`}</p>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Line 
                              type="monotone" 
                              dataKey={selectedColumn} 
                              stroke="#9b87f5" 
                              strokeWidth={2}
                              dot={false}
                              activeDot={{ r: 4, stroke: "#9b87f5", strokeWidth: 2, fill: "#1A1F2C" }}
                            />
                          </LineChart>
                        ) : (
                          <AreaChart data={csvData.rows}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#333" />
                            <XAxis 
                              dataKey={csvData.columns[0]} 
                              tick={{ fill: '#999' }} 
                              stroke="#444"
                              tickFormatter={(value) => formatDate(value)}
                            />
                            <YAxis 
                              tick={{ fill: '#999' }} 
                              stroke="#444"
                              domain={['auto', 'auto']}
                            />
                            <Tooltip 
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  return (
                                    <div className="bg-[#1A1F2C] border border-[#2A2F3C] p-2 text-xs">
                                      <p className="font-bold text-white">{payload[0].payload[csvData.columns[0]]}</p>
                                      <p className="text-[#9b87f5]">{`${selectedColumn}: ${formatCurrency(payload[0].value as number)}`}</p>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Area 
                              type="monotone" 
                              dataKey={selectedColumn} 
                              stroke="#9b87f5" 
                              fill="#9b87f5" 
                              fillOpacity={0.2}
                            />
                          </AreaChart>
                        )}
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ) : null}
      </div>
    </AppLayout>
  );
}
