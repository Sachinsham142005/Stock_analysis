
import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ArrowUpRight, ArrowDownRight, Search, Upload, Download, Filter, Star } from "lucide-react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import MarketAnalyzer from "@/components/market/MarketAnalyzer";

// Sample stock data
const allStocks = [
  { symbol: "AAPL", name: "Apple Inc.", price: 175.32, change: 2.35, changePercent: 1.35, volume: "34.5M", marketCap: "2.85T", sector: "Technology" },
  { symbol: "MSFT", name: "Microsoft Corporation", price: 328.79, change: 4.23, changePercent: 1.29, volume: "22.1M", marketCap: "2.44T", sector: "Technology" },
  { symbol: "GOOGL", name: "Alphabet Inc.", price: 145.68, change: -1.23, changePercent: -0.84, volume: "18.3M", marketCap: "1.85T", sector: "Technology" },
  { symbol: "AMZN", name: "Amazon.com Inc.", price: 136.71, change: 0.89, changePercent: 0.65, volume: "30.2M", marketCap: "1.41T", sector: "Consumer Cyclical" },
  { symbol: "META", name: "Meta Platforms Inc.", price: 437.29, change: 6.53, changePercent: 1.51, volume: "15.7M", marketCap: "1.12T", sector: "Communication Services" },
  { symbol: "TSLA", name: "Tesla Inc.", price: 233.10, change: -5.14, changePercent: -2.16, volume: "37.9M", marketCap: "741.2B", sector: "Automotive" },
  { symbol: "BRK.A", name: "Berkshire Hathaway Inc.", price: 593401.20, change: 1204.30, changePercent: 0.20, volume: "124", marketCap: "889.5B", sector: "Financials" },
  { symbol: "NVDA", name: "NVIDIA Corporation", price: 824.68, change: 12.34, changePercent: 1.52, volume: "28.6M", marketCap: "2.03T", sector: "Technology" },
  { symbol: "JPM", name: "JPMorgan Chase & Co.", price: 187.42, change: -0.32, changePercent: -0.17, volume: "8.4M", marketCap: "540.1B", sector: "Financials" },
  { symbol: "V", name: "Visa Inc.", price: 273.84, change: 2.61, changePercent: 0.96, volume: "6.2M", marketCap: "564.8B", sector: "Financials" },
  { symbol: "PG", name: "Procter & Gamble Co.", price: 163.72, change: 0.51, changePercent: 0.31, volume: "5.8M", marketCap: "386.5B", sector: "Consumer Defensive" },
  { symbol: "MA", name: "Mastercard Inc.", price: 456.31, change: 3.45, changePercent: 0.76, volume: "2.9M", marketCap: "428.3B", sector: "Financials" },
  { symbol: "HD", name: "Home Depot Inc.", price: 342.78, change: -1.43, changePercent: -0.42, volume: "3.4M", marketCap: "339.4B", sector: "Consumer Cyclical" },
  { symbol: "BAC", name: "Bank of America Corp.", price: 37.32, change: -0.78, changePercent: -2.05, volume: "42.3M", marketCap: "294.5B", sector: "Financials" },
  { symbol: "DIS", name: "Walt Disney Co.", price: 112.38, change: 1.24, changePercent: 1.12, volume: "12.7M", marketCap: "205.6B", sector: "Communication Services" },
  { symbol: "NFLX", name: "Netflix Inc.", price: 601.77, change: 8.32, changePercent: 1.40, volume: "4.1M", marketCap: "264.2B", sector: "Communication Services" },
  { symbol: "KO", name: "Coca-Cola Co.", price: 59.43, change: 0.23, changePercent: 0.39, volume: "13.2M", marketCap: "257.3B", sector: "Consumer Defensive" },
  { symbol: "CSCO", name: "Cisco Systems Inc.", price: 48.23, change: -0.42, changePercent: -0.86, volume: "19.6M", marketCap: "196.1B", sector: "Technology" },
  { symbol: "PFE", name: "Pfizer Inc.", price: 27.65, change: 0.34, changePercent: 1.25, volume: "35.7M", marketCap: "156.8B", sector: "Healthcare" },
  { symbol: "ADBE", name: "Adobe Inc.", price: 504.32, change: 7.82, changePercent: 1.58, volume: "3.6M", marketCap: "227.9B", sector: "Technology" },
];

// Sectors for filtering
const sectors = ["All", "Technology", "Financials", "Consumer Cyclical", "Communication Services", "Healthcare", "Automotive", "Consumer Defensive"];

export default function Market() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("stocks");
  const [activeSector, setActiveSector] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  // Filter stocks based on search term and sector
  const filteredStocks = allStocks.filter(stock => {
    const matchesSearch = 
      stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) || 
      stock.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSector = activeSector === "All" || stock.sector === activeSector;
    
    return matchesSearch && matchesSector;
  });
  
  // Pagination logic
  const indexOfLastStock = currentPage * itemsPerPage;
  const indexOfFirstStock = indexOfLastStock - itemsPerPage;
  const currentStocks = filteredStocks.slice(indexOfFirstStock, indexOfLastStock);
  const totalPages = Math.ceil(filteredStocks.length / itemsPerPage);
  
  // Add to watchlist function
  const addToWatchlist = (stock) => {
    // In a real app, this would save to the database
    toast({
      title: "Added to Watchlist",
      description: `${stock.symbol} has been added to your watchlist.`,
    });
  };

  return (
    <AppLayout>
      <div className="p-6 space-y-6 animate-fade-in">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Market</h1>
            <p className="text-muted-foreground">Track and analyze the latest market data</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative w-full md:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Search stocks..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 pr-4 w-full md:w-[250px]"
              />
            </div>
          </div>
        </div>

        <Tabs defaultValue="stocks" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="stocks">Stocks</TabsTrigger>
            <TabsTrigger value="analyzer">Market Analyzer</TabsTrigger>
          </TabsList>
          
          <TabsContent value="stocks" className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-xl">All Stocks</CardTitle>
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Filter:</span>
                  </div>
                </div>
                
                <div className="flex gap-2 overflow-x-auto py-2 scrollbar-none">
                  {sectors.map(sector => (
                    <Badge 
                      key={sector} 
                      variant={activeSector === sector ? "default" : "outline"} 
                      className="cursor-pointer transition-all hover:opacity-80 whitespace-nowrap"
                      onClick={() => setActiveSector(sector)}
                    >
                      {sector}
                    </Badge>
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Symbol</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead className="text-right">Price</TableHead>
                        <TableHead className="text-right">Change</TableHead>
                        <TableHead className="text-right">Volume</TableHead>
                        <TableHead className="text-right">Market Cap</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currentStocks.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center h-32">
                            No stocks found matching your criteria.
                          </TableCell>
                        </TableRow>
                      ) : (
                        currentStocks.map((stock) => (
                          <TableRow key={stock.symbol} className="group">
                            <TableCell className="font-medium">{stock.symbol}</TableCell>
                            <TableCell>{stock.name}</TableCell>
                            <TableCell className="text-right">${stock.price.toLocaleString()}</TableCell>
                            <TableCell className="text-right">
                              <div className={`flex items-center justify-end gap-1 ${stock.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                                {stock.change >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                                <span>{stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">{stock.volume}</TableCell>
                            <TableCell className="text-right">{stock.marketCap}</TableCell>
                            <TableCell className="text-right">
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => addToWatchlist(stock)}
                                className="opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <Star className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
                
                {filteredStocks.length > itemsPerPage && (
                  <Pagination className="mt-4">
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                          className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                        />
                      </PaginationItem>
                      
                      {[...Array(Math.min(totalPages, 5))].map((_, i) => {
                        const pageNum = i + 1;
                        return (
                          <PaginationItem key={pageNum}>
                            <PaginationLink 
                              isActive={currentPage === pageNum}
                              onClick={() => setCurrentPage(pageNum)}
                            >
                              {pageNum}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      })}
                      
                      {totalPages > 5 && (
                        <>
                          <PaginationItem>
                            <PaginationLink className="cursor-default hover:bg-transparent">...</PaginationLink>
                          </PaginationItem>
                          <PaginationItem>
                            <PaginationLink onClick={() => setCurrentPage(totalPages)}>
                              {totalPages}
                            </PaginationLink>
                          </PaginationItem>
                        </>
                      )}
                      
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                          className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="analyzer">
            <MarketAnalyzer />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
