
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import AuthTabs from "@/components/auth/AuthTabs";

export default function Auth() {
  const navigate = useNavigate();

  // Check if already logged in
  useEffect(() => {
    const isLoggedIn = localStorage.getItem("tradePulse-loggedIn");
    if (isLoggedIn) {
      navigate("/dashboard");
    }
  }, [navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-primary/5 to-background">
      <div className="w-full max-w-md p-4">
        <div className="text-center mb-8 animate-fade-in">
          <div className="mx-auto w-12 h-12 bg-primary rounded-full flex items-center justify-center mb-4 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary animate-pulse opacity-80"></div>
            <span className="relative text-white font-bold text-lg">TP</span>
          </div>
          <h1 className="text-3xl font-bold">Trade Pulse</h1>
          <p className="text-muted-foreground mt-2">Your pulse on the market</p>
        </div>
        
        <AuthTabs />
        
        <p className="text-center text-sm text-muted-foreground mt-6 animate-fade-in">
          By using Trade Pulse, you agree to our <a href="#" className="text-primary hover:underline">Terms of Service</a> and <a href="#" className="text-primary hover:underline">Privacy Policy</a>.
        </p>
      </div>
    </div>
  );
}
