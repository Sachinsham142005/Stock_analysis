
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Auth from "./Auth";

const Index = () => {
  const navigate = useNavigate();

  // Check if already logged in
  useEffect(() => {
    const isLoggedIn = localStorage.getItem("tradePulse-loggedIn");
    if (isLoggedIn) {
      navigate("/dashboard");
    }
  }, [navigate]);

  return <Auth />;
};

export default Index;
