import { useState, useEffect } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { TrendingUp, TrendingDown, DollarSign, Percent, RefreshCcw, Activity, Clock, BarChart as BarChartIcon, Search } from "lucide-react";
import { motion } from "framer-motion";

// Sample stock data for the simulation
const initialStocks = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 185.75,
    change: 4.25,
    changePercent: 2.35,
    historicalData: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      price: 175 + Math.random() * 15
    }))
  },
  {
    symbol: "MSFT",
    name: "Microsoft Corporation",
    price: 332.80,
    change: 5.15,
    changePercent: 1.57,
    historicalData: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      price: 320 + Math.random() * 20
    }))
  },
  {
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    price: 138.75,
    change: -2.25,
    changePercent: -1.59,
    historicalData: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      price: 135 + Math.random() * 10
    }))
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    price: 148.15,
    change: 2.05,
    changePercent: 1.40,
    historicalData: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      price: 140 + Math.random() * 12
    }))
  },
  {
    symbol: "TSLA",
    name: "Tesla Inc.",
    price: 230.45,
    change: 8.75,
    changePercent: 3.95,
    historicalData: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      price: 220 + Math.random() * 15
    }))
  },
  {
    symbol: "META",
    name: "Meta Platforms Inc.",
    price: 435.20,
    change: 7.30,
    changePercent: 1.70,
    historicalData: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      price: 420 + Math.random() * 20
    }))
  },
  {
    symbol: "NFLX",
    name: "Netflix Inc.",
    price: 605.75,
    change: -12.25,
    changePercent: -1.98,
    historicalData: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      price: 590 + Math.random() * 30
    }))
  },
  {
    symbol: "JPM",
    name: "JPMorgan Chase & Co.",
    price: 153.85,
    change: 1.65,
    changePercent: 1.09,
    historicalData: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      price: 150 + Math.random() * 8
    }))
  }
];

// Type for portfolio item
interface PortfolioItem {
  symbol: string;
  name: string;
  quantity: number;
  purchasePrice: number;
  currentPrice: number;
}

// Type for transaction history
interface Transaction {
  id: string;
  date: string;
  symbol: string;
  type: "buy" | "sell";
  quantity: number;
  price: number;
  total: number;
}

export default function Demo() {
  // Demo account state
  const [balance, setBalance] = useState(100000); // $100,000 initial balance
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stocks, setStocks] = useState(initialStocks);
  
  // UI state
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStock, setSelectedStock] = useState(stocks[0]);
  const [quantity, setQuantity] = useState("1");
  const [isLoading, setIsLoading] = useState(false);
  const [timeFrame, setTimeFrame] = useState("30d");

  // Filter stocks based on search
  const filteredStocks = stocks.filter(stock => 
    stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
    stock.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Calculate portfolio value
  const portfolioValue = portfolio.reduce(
    (sum, stock) => sum + stock.quantity * stock.currentPrice, 
    0
  );
  
  // Calculate total gain/loss
  const totalGainLoss = portfolio.reduce(
    (sum, stock) => sum + (stock.currentPrice - stock.purchasePrice) * stock.quantity, 
    0
  );
  
  // Calculate total gain/loss percentage
  const totalGainLossPercent = portfolio.length === 0 
    ? 0 
    : (totalGainLoss / (portfolioValue - totalGainLoss)) * 100;
  
  // Update stock prices randomly at regular intervals
  useEffect(() => {
    const interval = setInterval(() => {
      setStocks(prevStocks => 
        prevStocks.map(stock => {
          // Random price movement
          const priceChange = (Math.random() - 0.45) * (stock.price * 0.01);
          const newPrice = Math.max(0.01, stock.price + priceChange);
          
          // Update historical data
          const newHistoricalData = [...stock.historicalData];
          
          // Only add a new data point if the last one is from a different day
          const today = new Date().toISOString().split('T')[0];
          if (newHistoricalData[newHistoricalData.length - 1].date !== today) {
            newHistoricalData.push({
              date: today,
              price: newPrice
            });
            // Keep only the last 30 days
            if (newHistoricalData.length > 30) {
              newHistoricalData.shift();
            }
          } else {
            // Update today's price
            newHistoricalData[newHistoricalData.length - 1].price = newPrice;
          }
          
          return {
            ...stock,
            price: newPrice,
            change: newPrice - stock.historicalData[stock.historicalData.length - 2].price,
            changePercent: ((newPrice / stock.historicalData[stock.historicalData.length - 2].price) - 1) * 100,
            historicalData: newHistoricalData
          };
        })
      );
      
      // Update portfolio current prices
      setPortfolio(prevPortfolio => 
        prevPortfolio.map(item => {
          const stockData = stocks.find(s => s.symbol === item.symbol);
          return stockData 
            ? { ...item, currentPrice: stockData.price } 
            : item;
        })
      );
      
    }, 5000); // Update every 5 seconds
    
    return () => clearInterval(interval);
  }, [stocks]);
  
  // Handle buying stock
  const handleBuy = () => {
    const quantityNum = Number(quantity);
    
    if (isNaN(quantityNum) || quantityNum <= 0) {
      toast({
        title: "Invalid quantity",
        description: "Please enter a valid positive number",
        variant: "destructive"
      });
      return;
    }
    
    const totalCost = quantityNum * selectedStock.price;
    
    if (totalCost > balance) {
      toast({
        title: "Insufficient funds",
        description: "You don't have enough balance to make this purchase",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      // Update balance
      setBalance(prevBalance => prevBalance - totalCost);
      
      // Update portfolio
      setPortfolio(prevPortfolio => {
        const existingStock = prevPortfolio.find(item => item.symbol === selectedStock.symbol);
        
        if (existingStock) {
          // Update existing position
          const newAveragePrice = (
            (existingStock.quantity * existingStock.purchasePrice) + 
            (quantityNum * selectedStock.price)
          ) / (existingStock.quantity + quantityNum);
          
          return prevPortfolio.map(item => 
            item.symbol === selectedStock.symbol 
              ? {
                  ...item,
                  quantity: item.quantity + quantityNum,
                  purchasePrice: newAveragePrice,
                  currentPrice: selectedStock.price
                }
              : item
          );
        } else {
          // Add new position
          return [
            ...prevPortfolio,
            {
              symbol: selectedStock.symbol,
              name: selectedStock.name,
              quantity: quantityNum,
              purchasePrice: selectedStock.price,
              currentPrice: selectedStock.price
            }
          ];
        }
      });
      
      // Add to transaction history
      const transaction: Transaction = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        symbol: selectedStock.symbol,
        type: "buy",
        quantity: quantityNum,
        price: selectedStock.price,
        total: totalCost
      };
      
      setTransactions(prev => [transaction, ...prev]);
      
      toast({
        title: "Purchase Successful",
        description: `Bought ${quantityNum} shares of ${selectedStock.symbol} for $${totalCost.toFixed(2)}`,
      });
      
      // Reset quantity
      setQuantity("1");
      setIsLoading(false);
    }, 1000);
  };
  
  // Handle selling stock
  const handleSell = () => {
    const quantityNum = Number(quantity);
    
    if (isNaN(quantityNum) || quantityNum <= 0) {
      toast({
        title: "Invalid quantity",
        description: "Please enter a valid positive number",
        variant: "destructive"
      });
      return;
    }
    
    const existingStock = portfolio.find(item => item.symbol === selectedStock.symbol);
    
    if (!existingStock || existingStock.quantity < quantityNum) {
      toast({
        title: "Insufficient shares",
        description: `You don't have enough shares of ${selectedStock.symbol} to sell`,
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const totalValue = quantityNum * selectedStock.price;
      
      // Update balance
      setBalance(prevBalance => prevBalance + totalValue);
      
      // Update portfolio
      setPortfolio(prevPortfolio => {
        const newPortfolio = prevPortfolio.map(item => 
          item.symbol === selectedStock.symbol 
            ? {
                ...item,
                quantity: item.quantity - quantityNum
              }
            : item
        );
        
        // Remove stocks with 0 quantity
        return newPortfolio.filter(item => item.quantity > 0);
      });
      
      // Add to transaction history
      const transaction: Transaction = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        symbol: selectedStock.symbol,
        type: "sell",
        quantity: quantityNum,
        price: selectedStock.price,
        total: totalValue
      };
      
      setTransactions(prev => [transaction, ...prev]);
      
      toast({
        title: "Sale Successful",
        description: `Sold ${quantityNum} shares of ${selectedStock.symbol} for $${totalValue.toFixed(2)}`,
      });
      
      // Reset quantity
      setQuantity("1");
      setIsLoading(false);
    }, 1000);
  };
  
  // Reset the simulation
  const handleReset = () => {
    if (confirm("Are you sure you want to reset your demo portfolio? This action cannot be undone.")) {
      setBalance(100000);
      setPortfolio([]);
      setTransactions([]);
      toast({
        title: "Demo Reset",
        description: "Your demo portfolio has been reset to the initial state",
      });
    }
  };

  return (
    <AppLayout>
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Account Overview */}
          <Card className="lg:col-span-3">
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">Demo Trading Account</CardTitle>
              <CardDescription>
                Practice stock trading with a virtual $100,000 without any real money risk
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Cash Balance</h3>
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <p className="text-2xl font-bold">${balance.toFixed(2)}</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Portfolio Value</h3>
                      <BarChartIcon className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <p className="text-2xl font-bold">${portfolioValue.toFixed(2)}</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Total Value</h3>
                      <Activity className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <p className="text-2xl font-bold">${(balance + portfolioValue).toFixed(2)}</p>
                    <div className="flex items-center mt-1">
                      <span 
                        className={`text-sm font-medium flex items-center ${totalGainLoss >= 0 ? 'text-green-500' : 'text-red-500'}`}
                      >
                        {totalGainLoss >= 0 ? (
                          <TrendingUp className="mr-1 h-3 w-3" />
                        ) : (
                          <TrendingDown className="mr-1 h-3 w-3" />
                        )}
                        {totalGainLoss >= 0 ? '+' : ''}{totalGainLoss.toFixed(2)} ({totalGainLossPercent.toFixed(2)}%)
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-4" 
                onClick={handleReset}
              >
                <RefreshCcw className="mr-2 h-4 w-4" />
                Reset Demo
              </Button>
            </CardContent>
          </Card>
          
          {/* Stock Search */}
          <Card className="lg:col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Stock Search</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by symbol or name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
                
                <div className="h-[320px] overflow-y-auto space-y-2 pr-1">
                  {filteredStocks.length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground">
                      No stocks found matching your search.
                    </div>
                  ) : (
                    filteredStocks.map((stock) => (
                      <div 
                        key={stock.symbol}
                        className={`flex justify-between items-center p-2 rounded-md cursor-pointer border ${selectedStock.symbol === stock.symbol ? 'border-primary bg-primary/10' : 'border-border hover:bg-accent/50'}`}
                        onClick={() => setSelectedStock(stock)}
                      >
                        <div>
                          <h3 className="font-medium">{stock.symbol}</h3>
                          <p className="text-xs text-muted-foreground">{stock.name}</p>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">${stock.price.toFixed(2)}</div>
                          <div className={`text-xs flex items-center justify-end ${stock.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                            {stock.change >= 0 ? (
                              <TrendingUp className="mr-1 h-3 w-3" />
                            ) : (
                              <TrendingDown className="mr-1 h-3 w-3" />
                            )}
                            {stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)} 
                            <span className="ml-1">
                              ({stock.change >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%)
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Stock Details and Trading */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">{selectedStock.symbol}</CardTitle>
                    <CardDescription>{selectedStock.name}</CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold">${selectedStock.price.toFixed(2)}</div>
                    <div className={`flex items-center justify-end ${selectedStock.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {selectedStock.change >= 0 ? (
                        <TrendingUp className="mr-1 h-4 w-4" />
                      ) : (
                        <TrendingDown className="mr-1 h-4 w-4" />
                      )}
                      {selectedStock.change >= 0 ? '+' : ''}{selectedStock.change.toFixed(2)} 
                      <span className="ml-1">
                        ({selectedStock.change >= 0 ? '+' : ''}{selectedStock.changePercent.toFixed(2)}%)
                      </span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Stock Chart */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-medium">Price History</h3>
                      <div className="flex gap-1">
                        <Button 
                          variant={timeFrame === "7d" ? "default" : "outline"} 
                          size="sm" 
                          onClick={() => setTimeFrame("7d")}
                        >
                          7D
                        </Button>
                        <Button 
                          variant={timeFrame === "14d" ? "default" : "outline"} 
                          size="sm" 
                          onClick={() => setTimeFrame("14d")}
                        >
                          14D
                        </Button>
                        <Button 
                          variant={timeFrame === "30d" ? "default" : "outline"} 
                          size="sm" 
                          onClick={() => setTimeFrame("30d")}
                        >
                          30D
                        </Button>
                      </div>
                    </div>
                    
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={selectedStock.historicalData.slice(
                            timeFrame === "7d" ? -7 : 
                            timeFrame === "14d" ? -14 : -30
                          )}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                          <XAxis 
                            dataKey="date" 
                            tick={{ fontSize: 12 }}
                            tickFormatter={(value) => {
                              const date = new Date(value);
                              return `${date.getMonth() + 1}/${date.getDate()}`;
                            }}
                          />
                          <YAxis 
                            domain={['auto', 'auto']} 
                            tick={{ fontSize: 12 }}
                            tickFormatter={(value) => `$${value.toFixed(0)}`}
                          />
                          <Tooltip 
                            formatter={(value) => [`$${Number(value).toFixed(2)}`, 'Price']}
                            labelFormatter={(label) => {
                              const date = new Date(label);
                              return date.toLocaleDateString();
                            }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="price" 
                            stroke="#8884d8" 
                            strokeWidth={2}
                            dot={false}
                            activeDot={{ r: 5 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  {/* Trading Interface */}
                  <div className="bg-accent/20 p-4 rounded-lg">
                    <h3 className="font-medium mb-4">Place Order</h3>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="flex-1">
                        <label className="block text-sm font-medium mb-1">Quantity</label>
                        <div className="relative">
                          <Input
                            type="number"
                            min="1"
                            value={quantity}
                            onChange={(e) => setQuantity(e.target.value)}
                            className="pr-24"
                          />
                          <div className="absolute inset-y-0 right-0 flex items-center">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-full rounded-l-none px-2" 
                              onClick={() => setQuantity("1")}
                            >
                              Min
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-full rounded-none px-2 border-l" 
                              onClick={() => {
                                const max = Math.floor(balance / selectedStock.price);
                                setQuantity(max.toString());
                              }}
                            >
                              Max
                            </Button>
                          </div>
                        </div>
                        <div className="text-sm mt-2">
                          <span className="text-muted-foreground">Total Cost: </span>
                          <span className="font-medium">${(Number(quantity) * selectedStock.price).toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="flex-1 flex flex-col sm:flex-row gap-2">
                        <Button 
                          className="flex-1" 
                          onClick={handleBuy}
                          disabled={isLoading}
                        >
                          Buy
                        </Button>
                        <Button 
                          variant="outline" 
                          className="flex-1" 
                          onClick={handleSell}
                          disabled={isLoading}
                        >
                          Sell
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Portfolio Overview */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl">Portfolio</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="positions">
                  <TabsList className="w-full mb-4">
                    <TabsTrigger value="positions" className="flex-1">Positions</TabsTrigger>
                    <TabsTrigger value="history" className="flex-1">History</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="positions" className="mt-0">
                    <div className="space-y-4 max-h-[450px] overflow-y-auto pr-1">
                      {portfolio.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground">
                          Your portfolio is empty. Start trading to see your positions here.
                        </div>
                      ) : (
                        portfolio.map((item) => {
                          const currentValue = item.quantity * item.currentPrice;
                          const costBasis = item.quantity * item.purchasePrice;
                          const profit = currentValue - costBasis;
                          const profitPercent = (profit / costBasis) * 100;
                          
                          return (
                            <motion.div
                              key={item.symbol}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="p-3 border border-border rounded-lg"
                            >
                              <div className="flex justify-between items-center mb-2">
                                <div>
                                  <h3 className="font-medium">{item.symbol}</h3>
                                  <p className="text-xs text-muted-foreground">{item.name}</p>
                                </div>
                                <Badge>
                                  {item.quantity} {item.quantity === 1 ? 'share' : 'shares'}
                                </Badge>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                                <div>
                                  <span className="text-muted-foreground">Current:</span>{' '}
                                  <span className="font-medium">${item.currentPrice.toFixed(2)}</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Avg. Cost:</span>{' '}
                                  <span className="font-medium">${item.purchasePrice.toFixed(2)}</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Value:</span>{' '}
                                  <span className="font-medium">${currentValue.toFixed(2)}</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Cost:</span>{' '}
                                  <span className="font-medium">${costBasis.toFixed(2)}</span>
                                </div>
                              </div>
                              
                              <div className={`mt-2 text-sm font-medium flex items-center ${profit >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                                {profit >= 0 ? (
                                  <TrendingUp className="mr-1 h-3 w-3" />
                                ) : (
                                  <TrendingDown className="mr-1 h-3 w-3" />
                                )}
                                {profit >= 0 ? '+' : ''}{profit.toFixed(2)} 
                                <span className="ml-1">
                                  ({profit >= 0 ? '+' : ''}{profitPercent.toFixed(2)}%)
                                </span>
                              </div>
                            </motion.div>
                          );
                        })
                      )}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="history" className="mt-0">
                    <div className="space-y-3 max-h-[450px] overflow-y-auto pr-1">
                      {transactions.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground">
                          No transaction history yet. Start trading to see your history here.
                        </div>
                      ) : (
                        transactions.map((transaction) => {
                          const date = new Date(transaction.date);
                          
                          return (
                            <motion.div
                              key={transaction.id}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="p-3 border border-border rounded-lg"
                            >
                              <div className="flex justify-between items-start mb-1">
                                <div>
                                  <Badge 
                                    variant={transaction.type === "buy" ? "outline" : "secondary"}
                                    className={transaction.type === "buy" ? "border-green-500 text-green-500" : "border-red-500 text-red-500"}
                                  >
                                    {transaction.type === "buy" ? "BUY" : "SELL"}
                                  </Badge>
                                  <span className="font-medium ml-2">{transaction.symbol}</span>
                                </div>
                                <div className="flex items-center text-xs text-muted-foreground">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {date.toLocaleString()}
                                </div>
                              </div>
                              
                              <div className="flex justify-between text-sm mt-2">
                                <div>
                                  <span className="text-muted-foreground">Quantity:</span>{' '}
                                  <span className="font-medium">{transaction.quantity}</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Price:</span>{' '}
                                  <span className="font-medium">${transaction.price.toFixed(2)}</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Total:</span>{' '}
                                  <span className="font-medium">${transaction.total.toFixed(2)}</span>
                                </div>
                              </div>
                            </motion.div>
                          );
                        })
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
