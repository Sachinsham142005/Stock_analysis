
import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import ProfileDetails from "@/components/profile/ProfileDetails";
import AccountActivity from "@/components/profile/AccountActivity";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function Profile() {
  const [activeTab, setActiveTab] = useState("personal");
  
  return (
    <AppLayout>
      <div className="p-6">
        <Tabs defaultValue="personal" onValueChange={setActiveTab} className="w-full">
          <div className="mb-6">
            <TabsList className="w-full max-w-md">
              <TabsTrigger value="personal" className="flex-1">Personal Information</TabsTrigger>
              <TabsTrigger value="activity" className="flex-1">Account Activity</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="personal" className="mt-0">
            <ProfileDetails />
          </TabsContent>
          
          <TabsContent value="activity" className="mt-0">
            <AccountActivity />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
