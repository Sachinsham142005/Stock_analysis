
import { useState, useEffect } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Bookmark, ExternalLink, Filter, Search, Share2, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

// Sample news data
const newsData = [
  {
    id: 1,
    title: "Federal Reserve raises interest rates by 0.25%",
    summary: "The Federal Reserve has raised its benchmark interest rate by a quarter percentage point and signaled it may pause further increases, giving officials time to assess the economic impact of recent banking stress.",
    source: "Financial Times",
    category: "Economy",
    time: "2h ago",
    url: "#",
    impact: "high",
    imageUrl: "https://placehold.co/600x400/png"
  },
  {
    id: 2,
    title: "Apple stock reaches new all-time high ahead of AI product announcements",
    summary: "Apple shares reached a new all-time high today as investors anticipate significant AI product announcements at the upcoming WWDC developer conference. Analysts predict AI features across Apple's ecosystem.",
    source: "TechCrunch",
    category: "Technology",
    time: "4h ago",
    url: "#",
    impact: "medium",
    imageUrl: "https://placehold.co/600x400/png"
  },
  {
    id: 3,
    title: "Oil prices drop amid supply chain concerns",
    summary: "Oil prices fell on Wednesday as industry data showed an unexpected build in U.S. crude stocks, while investors worried about weakening demand in China and the U.S.",
    source: "Bloomberg",
    category: "Commodities",
    time: "6h ago",
    url: "#",
    impact: "medium",
    imageUrl: "https://placehold.co/600x400/png"
  },
  {
    id: 4,
    title: "Tesla exceeds quarterly delivery expectations",
    summary: "Tesla has beaten Wall Street delivery estimates for the second quarter, sending shares up despite broader market concerns about EV demand. The company delivered 466,140 vehicles globally in Q2.",
    source: "Reuters",
    category: "Automotive",
    time: "10h ago",
    url: "#",
    impact: "high",
    imageUrl: "https://placehold.co/600x400/png"
  },
  {
    id: 5,
    title: "New healthcare bill passes Senate vote",
    summary: "The Senate has passed a new healthcare bill aimed at reducing prescription drug prices and expanding insurance coverage. The bill now heads to the House for approval.",
    source: "CNBC",
    category: "Healthcare",
    time: "12h ago",
    url: "#",
    impact: "medium",
    imageUrl: "https://placehold.co/600x400/png"
  },
  {
    id: 6,
    title: "Retail sales show unexpected growth in Q2",
    summary: "Retail sales rose 0.6% in June, exceeding economist expectations of 0.3%. This marks the fourth consecutive month of growth, suggesting continued consumer resilience despite inflation concerns.",
    source: "Wall Street Journal",
    category: "Retail",
    time: "1d ago",
    url: "#",
    impact: "low",
    imageUrl: "https://placehold.co/600x400/png"
  },
  {
    id: 7,
    title: "Amazon acquires AI startup for $1.2 billion",
    summary: "Amazon has announced the acquisition of an AI startup specializing in supply chain optimization for $1.2 billion. The move is expected to enhance Amazon's logistics capabilities and delivery times.",
    source: "Business Insider",
    category: "Technology",
    time: "1d ago",
    url: "#",
    impact: "medium",
    imageUrl: "https://placehold.co/600x400/png"
  },
  {
    id: 8,
    title: "Bitcoin surges past $50,000 as institutional adoption increases",
    summary: "Bitcoin has surged past $50,000 for the first time in months as major financial institutions announce new cryptocurrency investment products and services.",
    source: "CoinDesk",
    category: "Cryptocurrency",
    time: "1d ago",
    url: "#",
    impact: "high",
    imageUrl: "https://placehold.co/600x400/png"
  }
];

// Sample market movers data
const marketMovers = [
  { symbol: "AAPL", name: "Apple Inc.", price: 185.75, change: +4.25, changePercent: +2.35 },
  { symbol: "TSLA", name: "Tesla Inc.", price: 230.45, change: +8.75, changePercent: +3.95 },
  { symbol: "AMZN", name: "Amazon.com Inc.", price: 138.75, change: -2.25, changePercent: -1.59 },
  { symbol: "MSFT", name: "Microsoft Corp.", price: 332.80, change: +5.15, changePercent: +1.57 },
  { symbol: "GOOGL", name: "Alphabet Inc.", price: 148.15, change: +2.05, changePercent: +1.40 },
  { symbol: "META", name: "Meta Platforms", price: 292.60, change: -3.40, changePercent: -1.15 }
];

const getImpactColor = (impact: "high" | "medium" | "low") => {
  switch (impact) {
    case "high":
      return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400";
    case "medium":
      return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400";
    case "low":
      return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400";
    default:
      return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400";
  }
};

// Categories for filtering
const categories = [
  "All", "Economy", "Technology", "Cryptocurrency", "Commodities", "Healthcare", "Retail", "Automotive"
];

export default function News() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [isLoading, setIsLoading] = useState(true);
  
  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);
  
  // Filter news based on search and category
  const filteredNews = newsData.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.summary.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <AppLayout>
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Market Movers */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Market Movers
                </CardTitle>
              </CardHeader>
              <CardContent className="overflow-hidden">
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ staggerChildren: 0.1 }}
                  className="space-y-4"
                >
                  {marketMovers.map((stock) => (
                    <motion.div
                      key={stock.symbol}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center justify-between p-2 rounded-md border border-border hover:bg-accent transition-colors"
                    >
                      <div>
                        <div className="font-medium">{stock.symbol}</div>
                        <div className="text-xs text-muted-foreground">{stock.name}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">${stock.price.toFixed(2)}</div>
                        <div className={`text-xs ${stock.change > 0 ? 'text-green-500' : 'text-red-500'}`}>
                          {stock.change > 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePercent > 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%)
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              </CardContent>
            </Card>
          </div>
          
          {/* News Feed */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <CardTitle className="text-2xl font-bold">Financial News</CardTitle>
                  
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search news..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9 w-full sm:w-[200px] h-9"
                      />
                    </div>
                    <Button variant="outline" size="icon" className="h-9 w-9">
                      <Filter className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2 mt-4">
                  {categories.map(category => (
                    <Badge
                      key={category}
                      variant={selectedCategory === category ? "default" : "outline"}
                      className="cursor-pointer transition-all hover:opacity-80"
                      onClick={() => setSelectedCategory(category)}
                    >
                      {category}
                    </Badge>
                  ))}
                </div>
              </CardHeader>
              
              <CardContent>
                <Tabs defaultValue="latest" className="w-full">
                  <TabsList className="mb-4">
                    <TabsTrigger value="latest">Latest</TabsTrigger>
                    <TabsTrigger value="trending">Trending</TabsTrigger>
                    <TabsTrigger value="market-impact">Market Impact</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="latest" className="mt-0">
                    <div className="space-y-6">
                      {isLoading ? (
                        // Loading skeletons
                        Array(4).fill(0).map((_, i) => (
                          <div key={i} className="flex flex-col sm:flex-row gap-4 p-4 border border-border rounded-lg">
                            <Skeleton className="h-32 w-full sm:w-48 rounded-md" />
                            <div className="flex-1 space-y-2">
                              <Skeleton className="h-6 w-3/4" />
                              <Skeleton className="h-4 w-full" />
                              <Skeleton className="h-4 w-full" />
                              <div className="flex items-center justify-between pt-2">
                                <Skeleton className="h-4 w-24" />
                                <div className="flex gap-1">
                                  <Skeleton className="h-8 w-8 rounded-md" />
                                  <Skeleton className="h-8 w-8 rounded-md" />
                                </div>
                              </div>
                            </div>
                          </div>
                        ))
                      ) : filteredNews.length === 0 ? (
                        <div className="text-center py-12 text-muted-foreground">
                          No news articles found matching your criteria.
                        </div>
                      ) : (
                        filteredNews.map((news) => (
                          <motion.div
                            key={news.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="flex flex-col sm:flex-row gap-4 p-4 border border-border rounded-lg hover:bg-accent/5 transition-colors"
                          >
                            <div className="sm:w-48 h-32 overflow-hidden rounded-md shrink-0">
                              <img 
                                src={news.imageUrl} 
                                alt={news.title} 
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-1 space-y-2">
                              <h3 className="font-medium text-lg line-clamp-2">{news.title}</h3>
                              <p className="text-sm text-muted-foreground line-clamp-2">{news.summary}</p>
                              <div className="flex flex-wrap items-center gap-2 pt-1">
                                <Badge variant="outline" className="text-xs font-normal">
                                  {news.category}
                                </Badge>
                                <Badge
                                  variant="outline"
                                  className={`text-xs font-normal ${getImpactColor(news.impact as "high" | "medium" | "low")}`}
                                >
                                  {news.impact.charAt(0).toUpperCase() + news.impact.slice(1)} Impact
                                </Badge>
                              </div>
                              <div className="flex items-center justify-between pt-1">
                                <span className="text-xs text-muted-foreground">
                                  {news.source} · {news.time}
                                </span>
                                <div className="flex gap-1">
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Bookmark className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Share2 className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <ExternalLink className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))
                      )}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="trending" className="mt-0">
                    <div className="text-center py-12 text-muted-foreground">
                      Trending news content will be shown here.
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="market-impact" className="mt-0">
                    <div className="text-center py-12 text-muted-foreground">
                      News with significant market impact will be shown here.
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
